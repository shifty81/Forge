Option Explicit
Dim shell, fso, base, target, args, i
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
target = base & "\Forge.vbs"
args = ""
For i = 0 To WScript.Arguments.Count - 1
    args = args & " " & Chr(34) & Replace(WScript.Arguments(i), Chr(34), Chr(34) & Chr(34)) & Chr(34)
Next
shell.Run "wscript.exe " & Chr(34) & target & Chr(34) & args, 0, False
