# Forge — Universal Project Control Center

Forge is the standalone, project-neutral operations authority extracted from the proven Project Control Center implementations used across Havenwild, Cortex, Codename Subspace, Windstead, and other projects.

This tree starts from `ProjectControlCenter_Standalone_PCC-GUI-0.10.2_20260909.zip` and preserves that package as the donor baseline while moving universal behavior into Forge-owned modules.

## Start Forge on Windows

- `Forge.vbs` — preferred GUI launcher, no bootstrap console.
- `Forge.cmd` — visible diagnostic launcher.
- `ForgeConsole.cmd --root <project>` — guaranteed console fallback.
- `VerifyForge.cmd` — standalone verification.

Legacy `ProjectControlCenter.cmd/.vbs` launchers remain as compatibility aliases and now launch Forge.

## What F01-F10 already normalize

1. **Forge identity and persistent paths** — new registry/Vault roots with legacy PCC registry adoption.
2. **Standalone Forge GUI authority** — `ForgeGui.py` is canonical; `CortexPCCGui.py` is a compatibility shim.
3. **Project Health** — Registered Projects now includes a computed `Health` column (`GREEN`, `WARN`, `FAIL`).
4. **Mandatory source-control visibility** — Git status plus GitHub and local Forgejo remote detection.
5. **Downloads watcher** — Forge continuously watches configured intake folders for completed manifest-bearing patch ZIPs.
6. **Vault quarantine/queue** — accepted patch transports are hash-verified before the browser/download copy is removed.
7. **Next-build staging** — queued Vault patches are staged into the matching project's `updates/inbox` before build/gate operations.
8. **Existing patch-authority reuse** — Forge invokes the project's proven `patch-apply` provider during migration instead of inventing a weaker patch engine.
9. **Applied-patch reconciliation** — project receipts promote queued transports into Forge Vault's durable `patches/applied` archive.
10. **Console recovery surface + self-hosting** — Forge has its own simplified console fallback, project contract, self-test and quality gate.

## Persistent data

Canonical overrides:

```text
FORGE_DATA_ROOT
FORGE_PROJECT_REGISTRY
FORGE_VAULT_ROOT
FORGE_INTAKE_PATHS
FORGE_FORGEJO_HOSTS
```

Default Windows policy:

```text
Registry: %LOCALAPPDATA%\Forge\project_registry.json
Vault:    D:\Forge\Vault          (when D: exists)
          %LOCALAPPDATA%\Forge\Vault otherwise
Intake:   %USERPROFILE%\Downloads
```

Old `%LOCALAPPDATA%\ProjectControlCenter\project_registry.json` is copied into the Forge registry once when Forge has no registry yet. The legacy file is not deleted.

## Patch intake contract in this milestone

Forge only treats a ZIP as a patch transport when it contains exactly one top-level `PATCH_MANIFEST.json`. It validates ZIP path safety, requires a safe patch ID, hashes the transport, copies it to Vault, verifies the destination hash, writes a canonical SHA-256 sidecar and receipt, then removes the original Downloads copy.

The current migration path deliberately keeps project-native patch application authoritative. At the next Build/Quick/Fast/Full operation Forge stages queued patches for that project and invokes `patch-apply`; successful project receipts are then reconciled back into Forge's durable archive.

## Safety boundary

Forge F01-F10 does **not** yet claim that the final universal patch engine, GREEN authority, GitHub write authority, Forgejo provisioning, packaged EXE updater, or Cortex machine API are finished. The architecture now has a clean place for each of those authorities, and existing project providers remain compatibility donors until Forge replaces them with certified universal implementations.

## Verification

```text
python app/ForgeStandalone.py --self-test
python tools/ForgeGate.py full
python -m unittest discover -s tests -v
```
