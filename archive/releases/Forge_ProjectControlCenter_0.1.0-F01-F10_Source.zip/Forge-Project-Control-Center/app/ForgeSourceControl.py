#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Sequence
from urllib.parse import urlparse

FORGE_SOURCE_VERSION = "FORGE-SOURCE-0.1"


def _run(root: Path, *args: str, timeout: float = 20.0) -> subprocess.CompletedProcess[str]:
    git = shutil.which("git") or "git"
    return subprocess.run(
        [git, "-C", str(root), *args],
        cwd=str(root), stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        text=True, encoding="utf-8", errors="replace", timeout=timeout, check=False,
        creationflags=0,
    )


def _remote_kind(name: str, url: str) -> str:
    low_name = name.casefold()
    low = url.casefold()
    if "github.com" in low:
        return "github"
    hosts = {x.strip().casefold() for x in str(os.environ.get("FORGE_FORGEJO_HOSTS") or "").split(";") if x.strip()}
    if "forgejo" in low_name or "forgejo" in low:
        return "forgejo"
    if any(token in low for token in ("localhost", "127.0.0.1", "::1")):
        return "forgejo"
    if any(host in low for host in hosts):
        return "forgejo"
    return "other"


def status(root: Path) -> dict[str, Any]:
    root = root.expanduser().resolve()
    ready = bool(shutil.which("git")) and (root / ".git").exists()
    out: dict[str, Any] = {
        "schema": "forge.source.status.v1",
        "version": FORGE_SOURCE_VERSION,
        "gitReady": ready,
        "branch": "",
        "head": "",
        "clean": False,
        "ahead": None,
        "behind": None,
        "remotes": [],
        "githubConfigured": False,
        "forgejoConfigured": False,
    }
    if not ready:
        return out
    cp = _run(root, "status", "--porcelain=v1", "--untracked-files=all")
    out["clean"] = cp.returncode == 0 and not cp.stdout.strip()
    branch = _run(root, "branch", "--show-current")
    if branch.returncode == 0:
        out["branch"] = branch.stdout.strip()
    head = _run(root, "rev-parse", "HEAD")
    if head.returncode == 0:
        out["head"] = head.stdout.strip()
    counts = _run(root, "rev-list", "--left-right", "--count", "HEAD...@{upstream}")
    if counts.returncode == 0:
        parts = counts.stdout.split()
        if len(parts) == 2 and all(x.isdigit() for x in parts):
            out["ahead"], out["behind"] = int(parts[0]), int(parts[1])
    remotes = _run(root, "remote", "-v")
    seen: set[tuple[str, str]] = set()
    if remotes.returncode == 0:
        for line in remotes.stdout.splitlines():
            parts = line.split()
            if len(parts) < 2:
                continue
            name, url = parts[0], parts[1]
            key = (name, url)
            if key in seen:
                continue
            seen.add(key)
            kind = _remote_kind(name, url)
            out["remotes"].append({"name": name, "url": url, "kind": kind})
            if kind == "github":
                out["githubConfigured"] = True
            elif kind == "forgejo":
                out["forgejoConfigured"] = True
    return out


def main(argv: Sequence[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Forge universal Git/GitHub/Forgejo status authority")
    ap.add_argument("action", choices=("status-json", "remotes-json"))
    ap.add_argument("--root", required=True)
    ns = ap.parse_args(argv)
    payload = status(Path(ns.root))
    if ns.action == "remotes-json":
        payload = {"remotes": payload["remotes"], "githubConfigured": payload["githubConfigured"], "forgejoConfigured": payload["forgejoConfigured"]}
    print(json.dumps(payload, separators=(",", ":"), sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
