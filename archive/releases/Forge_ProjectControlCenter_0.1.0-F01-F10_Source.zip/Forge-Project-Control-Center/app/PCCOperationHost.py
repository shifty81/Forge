#!/usr/bin/env python3
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path
from typing import Sequence

from PCCRepoHygiene import prepare
from ForgeIntake import reconcile_project, stage_for_project

VERSION = "FORGE-OPERATION-HOST-0.2"

# Operations that should begin and end from a transport-clean repository root.
CLEAN_OPERATIONS = {
    "full", "quick", "fast", "build", "build-release", "patch-apply", "self-test",
    "commit-green", "commit-push-green", "push", "git-pull",
    "debug-bundle", "doctor", "root-hygiene", "root-hygiene-fix",
}

PATCH_APPLY_OPERATIONS = {"full", "quick", "fast", "build", "build-release"}


def _print_hygiene(label: str, root: Path) -> int:
    try:
        result = prepare(root, apply=True)
    except Exception as exc:
        print(f"[FAIL] {label} repository transport hygiene failed: {exc}", flush=True)
        return 1
    moved = int(result.get("moved", 0) or 0)
    if moved:
        print(f"[PASS] {label} repository transport hygiene moved {moved} operational artifact(s).", flush=True)
        for row in result.get("moves", []):
            print(f"  MOVE {Path(row['source']).name} -> {row['destination']}", flush=True)
    else:
        print(f"[PASS] {label} repository transport hygiene clean.", flush=True)
    pending = result.get("pendingPatchTransports") or []
    if pending:
        print(f"[INFO] {len(pending)} pending patch transport(s) preserved for project update authority.", flush=True)
    return 0


def _run(argv: Sequence[str], root: Path) -> int:
    env = os.environ.copy()
    env["PCC_OPERATION_HOST_ACTIVE"] = "1"
    env["FORGE_OPERATION_HOST_ACTIVE"] = "1"
    proc = subprocess.Popen(list(argv), cwd=str(root), stdin=subprocess.DEVNULL, env=env)
    return int(proc.wait())


def _provider_variant(child: Sequence[str], current_operation: str, replacement: str) -> list[str]:
    argv = list(child)
    # BackendClient provider argv is: python, provider.py, command, --root, <root>, ...
    # Find the command token rather than assuming an exact interpreter path layout.
    for index in range(min(5, len(argv))):
        if argv[index] == current_operation:
            argv[index] = replacement
            return argv
    raise RuntimeError(f"cannot derive provider operation {replacement!r} from child argv")


def _apply_staged_updates(root: Path, operation: str, child: Sequence[str]) -> int:
    try:
        staged = stage_for_project(root)
    except Exception as exc:
        print(f"[FAIL] Forge could not stage queued Vault patch(es): {exc}", flush=True)
        return 1
    count = int(staged.get("staged", 0) or 0)
    if count == 0:
        return 0
    print(f"[INFO] Forge staged {count} queued patch(es) for the next {operation} operation.", flush=True)
    try:
        apply_child = _provider_variant(child, operation, "patch-apply")
    except Exception as exc:
        print(f"[FAIL] Queued Forge patches require a project patch authority: {exc}", flush=True)
        return 1
    rc = _run(apply_child, root)
    if rc != 0:
        print(f"[FAIL] Project patch authority rejected/failed queued Forge patch(es), exit={rc}.", flush=True)
        return rc
    try:
        reconciled = reconcile_project(root)
        count = int(reconciled.get("reconciled", 0) or 0)
        if count:
            print(f"[PASS] Forge reconciled {count} applied patch(es) into the durable Vault archive.", flush=True)
    except Exception as exc:
        print(f"[WARN] Patch applied, but Forge Vault reconciliation needs attention: {exc}", flush=True)
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Forge operation host")
    ap.add_argument("--root", required=True)
    ap.add_argument("--operation", required=True)
    ap.add_argument("child", nargs=argparse.REMAINDER)
    ns = ap.parse_args(argv)
    root = Path(ns.root).expanduser().resolve()
    operation = str(ns.operation)
    child = list(ns.child)
    if child and child[0] == "--":
        child = child[1:]
    if not child:
        print("[FAIL] PCC operation host received no provider command.", flush=True)
        return 2

    do_clean = operation in CLEAN_OPERATIONS
    if do_clean and _print_hygiene("Pre-operation", root) != 0:
        return 1

    print(f"[FORGE] Operation host {VERSION}: {operation}", flush=True)
    rc = 1
    try:
        if operation == "patch-apply":
            try:
                staged = stage_for_project(root)
                count = int(staged.get("staged", 0) or 0)
                if count:
                    print(f"[INFO] Forge staged {count} queued Vault patch(es) for explicit apply.", flush=True)
            except Exception as exc:
                print(f"[FAIL] Forge could not stage queued Vault patch(es): {exc}", flush=True)
                return 1
        elif operation in PATCH_APPLY_OPERATIONS:
            patch_rc = _apply_staged_updates(root, operation, child)
            if patch_rc != 0:
                return patch_rc
        rc = _run(child, root)
        if rc == 0 and operation == "patch-apply":
            try:
                reconciled = reconcile_project(root)
                count = int(reconciled.get("reconciled", 0) or 0)
                if count:
                    print(f"[PASS] Forge reconciled {count} applied patch(es) into the durable Vault archive.", flush=True)
            except Exception as exc:
                print(f"[WARN] Patch applied, but Forge Vault reconciliation needs attention: {exc}", flush=True)
    finally:
        if do_clean:
            clean_rc = _print_hygiene("Post-operation", root)
            if rc == 0 and clean_rc != 0:
                rc = clean_rc
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
