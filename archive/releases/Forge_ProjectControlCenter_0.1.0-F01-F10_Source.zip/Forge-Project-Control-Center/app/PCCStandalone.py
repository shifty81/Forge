#!/usr/bin/env python3
"""Compatibility entrypoint. ForgeStandalone.py is authoritative."""
from ForgeStandalone import *  # noqa: F401,F403
from ForgeStandalone import main

if __name__ == "__main__":
    raise SystemExit(main())
