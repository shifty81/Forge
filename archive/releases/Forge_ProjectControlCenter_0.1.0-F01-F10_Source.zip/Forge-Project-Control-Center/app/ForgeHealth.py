#!/usr/bin/env python3
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from PCCAutoAdapter import status_payload
from PCCSurfaceCommon import BackendClient, ProjectContract, SurfaceError

FORGE_HEALTH_VERSION = "FORGE-HEALTH-0.1"


@dataclass(frozen=True)
class ProjectHealth:
    level: str
    reasons: tuple[str, ...] = field(default_factory=tuple)
    status: dict[str, Any] = field(default_factory=dict, compare=False)
    provider: str = ""

    @property
    def label(self) -> str:
        if not self.reasons:
            return self.level
        return f"{self.level} — {self.reasons[0]}"


def _push(bucket: list[str], message: str) -> None:
    if message and message not in bucket:
        bucket.append(message)


def evaluate_project(root: Path, contract: ProjectContract | None = None) -> ProjectHealth:
    root = root.expanduser().resolve()
    failures: list[str] = []
    warnings: list[str] = []
    provider = ""

    if not root.is_dir():
        return ProjectHealth("FAIL", ("project root missing",), {}, "")

    try:
        contract = contract or ProjectContract.load(root)
    except Exception as exc:
        return ProjectHealth("FAIL", (f"project discovery failed: {exc}",), {}, "")

    try:
        backend = BackendClient(root, contract)
        provider = backend.provider_label
    except SurfaceError as exc:
        _push(failures, f"PCC authority unavailable: {exc}")
    except Exception as exc:
        _push(failures, f"PCC authority invalid: {exc}")

    try:
        status = status_payload(root)
    except Exception as exc:
        return ProjectHealth("FAIL", tuple(failures + [f"health scan failed: {exc}"]), {}, provider)

    git = status.get("git") or {}
    patches = status.get("patches") or {}
    hygiene = status.get("hygiene") or {}
    tools = status.get("tools") or {}
    source_control = status.get("sourceControl") or {}

    # If this is a Git working tree, Git being unavailable is a hard operational failure.
    if (root / ".git").exists() and not git.get("gitReady"):
        _push(failures, "Git repository detected but Git is unavailable")
    elif git.get("gitReady"):
        if not git.get("clean"):
            changed = int(git.get("staged", 0) or 0) + int(git.get("unstaged", 0) or 0) + int(git.get("untracked", 0) or 0)
            _push(warnings, f"source modified ({changed})" if changed else "source modified")
        if git.get("greenMarker") and not git.get("greenMatch"):
            _push(warnings, "certified GREEN is stale")
        elif not git.get("greenMarker"):
            _push(warnings, "no certified GREEN marker")
        ahead = git.get("ahead")
        behind = git.get("behind")
        if behind not in (None, 0):
            _push(warnings, f"remote behind/ahead mismatch ({ahead or 0}↑ {behind}↓)")
        elif ahead not in (None, 0):
            _push(warnings, f"local branch ahead by {ahead}")

    invalid = int(patches.get("invalid", 0) or 0)
    pending = int(patches.get("pending", 0) or 0)
    if invalid:
        _push(failures, f"{invalid} invalid patch(es)")
    if pending:
        _push(warnings, f"{pending} pending update(s)")

    if not hygiene.get("clean", True):
        _push(warnings, f"repository hygiene has {hygiene.get('violationCount', '?')} issue(s)")

    missing_tools = [name for name, ready in tools.items() if ready is False]
    if missing_tools:
        _push(failures, "required toolchain missing: " + ", ".join(sorted(missing_tools)))

    # GitHub and Cortex-owned/local Forgejo are mandatory Forge source-control surfaces.
    # During migration their absence is a normalization warning rather than a blocker for
    # local build/recovery operations.
    if git.get("gitReady"):
        if not source_control.get("githubConfigured"):
            _push(warnings, "GitHub remote not configured")
        if not source_control.get("forgejoConfigured"):
            _push(warnings, "Forgejo remote not configured")

    level = "FAIL" if failures else ("WARN" if warnings else "GREEN")
    reasons = tuple(failures + warnings)
    return ProjectHealth(level, reasons, status, provider)
