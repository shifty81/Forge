#!/usr/bin/env python3
"""Compatibility shim for PCC-GUI-0.10.x launchers.

Forge owns the GUI implementation. Existing project-side references importing
CortexPCCGui continue to work during the one-way migration.
"""
from ForgeGui import ForgeGui, GUI_VERSION, build_parser, main

CortexPCCGui = ForgeGui

if __name__ == "__main__":
    raise SystemExit(main())
