#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sqlite3
import stat
import time
import uuid
import zipfile
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any, Iterable, Sequence

from ForgePaths import downloads_roots, vault_root

FORGE_INTAKE_VERSION = "FORGE-INTAKE-0.1"
TEMP_SUFFIXES = {".crdownload", ".part", ".download", ".tmp"}
NON_PATCH_RE = re.compile(r"(?:debugbundle|debug[-_ ]?bundle|handoff|source[-_ ]?(?:rollup|bundle)|rollup|backup|support[-_ ]?bundle|archive)", re.I)
PATCH_NAME_RE = re.compile(r"(?:root[-_ ]?patch|rootpatch|incremental[-_ ]?patch|patch[-_ ]?update|[_-]patch[_-]|^patch[_-])", re.I)
PATCH_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{2,127}$")
MAX_FILES = 5000
MAX_UNCOMPRESSED = 2 * 1024 * 1024 * 1024
MAX_SINGLE_FILE = 512 * 1024 * 1024
MAX_PATH_CHARS = 260
DEFAULT_STABLE_SECONDS = 2.0


class IntakeError(RuntimeError):
    pass


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _db_path() -> Path:
    path = vault_root() / "catalog" / "forge_intake.db"
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def _connect() -> sqlite3.Connection:
    db = sqlite3.connect(_db_path())
    db.execute("PRAGMA journal_mode=WAL")
    db.executescript(
        """
        CREATE TABLE IF NOT EXISTS observations(
            source_path TEXT PRIMARY KEY,
            size INTEGER NOT NULL,
            mtime_ns INTEGER NOT NULL,
            stable_count INTEGER NOT NULL,
            first_seen_utc TEXT NOT NULL,
            last_seen_utc TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS intake_items(
            intake_id TEXT PRIMARY KEY,
            source_name TEXT NOT NULL,
            original_path TEXT NOT NULL,
            sha256 TEXT NOT NULL,
            bytes INTEGER NOT NULL,
            classification TEXT NOT NULL,
            state TEXT NOT NULL,
            target_project TEXT NOT NULL,
            patch_id TEXT NOT NULL,
            received_utc TEXT NOT NULL,
            vault_path TEXT NOT NULL,
            manifest_json TEXT NOT NULL,
            error TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_intake_state ON intake_items(state);
        CREATE INDEX IF NOT EXISTS idx_intake_project ON intake_items(target_project, state);
        CREATE UNIQUE INDEX IF NOT EXISTS idx_intake_hash_state ON intake_items(sha256, state);
        """
    )
    return db


def _safe_zip_entries(zf: zipfile.ZipFile) -> list[str]:
    names: list[str] = []
    total = 0
    for info in zf.infolist():
        raw = info.filename.replace("\\", "/")
        if not raw or raw.endswith("/"):
            continue
        p = PurePosixPath(raw)
        if p.is_absolute() or re.match(r"^[A-Za-z]:", raw) or any(part in {"", ".", ".."} for part in p.parts):
            raise IntakeError(f"unsafe ZIP path: {raw}")
        normalized = "/".join(p.parts)
        if len(normalized) > MAX_PATH_CHARS:
            raise IntakeError(f"ZIP path too long: {normalized}")
        mode = (info.external_attr >> 16) & 0xFFFF
        if mode and (stat.S_ISLNK(mode) or stat.S_ISCHR(mode) or stat.S_ISBLK(mode) or stat.S_ISFIFO(mode)):
            raise IntakeError(f"non-regular ZIP entry: {normalized}")
        if info.file_size > MAX_SINGLE_FILE:
            raise IntakeError(f"ZIP entry exceeds safety budget: {normalized}")
        total += info.file_size
        if total > MAX_UNCOMPRESSED:
            raise IntakeError("ZIP exceeds uncompressed safety budget")
        names.append(normalized)
    if len(names) > MAX_FILES + 5:
        raise IntakeError(f"ZIP exceeds file-count safety budget ({MAX_FILES})")
    folded = [name.casefold() for name in names]
    if len(folded) != len(set(folded)):
        raise IntakeError("ZIP contains duplicate paths (case-insensitive)")
    return names


def inspect_patch(path: Path) -> dict[str, Any]:
    if path.suffix.casefold() != ".zip":
        raise IntakeError("not a ZIP transport")
    with zipfile.ZipFile(path, "r") as zf:
        names = _safe_zip_entries(zf)
        matches = [name for name in names if name.casefold() == "patch_manifest.json"]
        if len(matches) != 1:
            raise IntakeError("patch transport requires exactly one top-level PATCH_MANIFEST.json")
        manifest_name = matches[0]
        if PurePosixPath(manifest_name).parent != PurePosixPath("."):
            raise IntakeError("PATCH_MANIFEST.json must be top-level")
        try:
            manifest = json.loads(zf.read(manifest_name).decode("utf-8-sig"))
        except Exception as exc:
            raise IntakeError(f"invalid PATCH_MANIFEST.json: {exc}") from exc
        if not isinstance(manifest, dict):
            raise IntakeError("PATCH_MANIFEST.json must be an object")

    patch_id = str(manifest.get("patchId") or manifest.get("patch_id") or "").strip()
    if not PATCH_ID_RE.fullmatch(patch_id):
        raise IntakeError("patchId must be 3-128 safe identifier characters")
    project = str(
        manifest.get("project")
        or manifest.get("projectId")
        or manifest.get("project_id")
        or manifest.get("targetProject")
        or manifest.get("target_project")
        or "unassigned"
    ).strip()
    target = manifest.get("target")
    if project == "unassigned" and isinstance(target, dict):
        project = str(target.get("project") or target.get("projectId") or target.get("id") or "unassigned").strip()
    schema = str(manifest.get("schema") or "").strip()
    return {
        "patchId": patch_id,
        "project": project or "unassigned",
        "schema": schema,
        "title": str(manifest.get("title") or patch_id),
        "manifest": manifest,
    }


def looks_like_patch(path: Path) -> bool:
    if not path.is_file() or path.suffix.casefold() != ".zip":
        return False
    if NON_PATCH_RE.search(path.name):
        return False
    try:
        with zipfile.ZipFile(path, "r") as zf:
            return any(name.replace("\\", "/").casefold() == "patch_manifest.json" for name in zf.namelist())
    except Exception:
        return False


def _observe(path: Path) -> int:
    stat_result = path.stat()
    key = os.path.normcase(str(path.resolve()))
    now = utc_now()
    db = _connect()
    try:
        row = db.execute("SELECT size,mtime_ns,stable_count,first_seen_utc FROM observations WHERE source_path=?", (key,)).fetchone()
        if row and int(row[0]) == int(stat_result.st_size) and int(row[1]) == int(stat_result.st_mtime_ns):
            stable = int(row[2]) + 1
            first = str(row[3])
        else:
            stable = 1
            first = now
        db.execute(
            "INSERT OR REPLACE INTO observations(source_path,size,mtime_ns,stable_count,first_seen_utc,last_seen_utc) VALUES(?,?,?,?,?,?)",
            (key, int(stat_result.st_size), int(stat_result.st_mtime_ns), stable, first, now),
        )
        db.commit()
        return stable
    finally:
        db.close()


def _already_ingested(digest: str) -> bool:
    db = _connect()
    try:
        row = db.execute(
            "SELECT 1 FROM intake_items WHERE sha256=? AND state IN ('QUEUED','STAGED','APPLIED','CERTIFIED') LIMIT 1",
            (digest,),
        ).fetchone()
        return bool(row)
    finally:
        db.close()


def _write_receipt(item: dict[str, Any]) -> Path:
    folder = vault_root() / "patches" / "receipts"
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{item['intake_id']}.json"
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(item, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(temp, path)
    return path


def _persist_item(item: dict[str, Any]) -> None:
    db = _connect()
    try:
        db.execute(
            """
            INSERT INTO intake_items(
                intake_id,source_name,original_path,sha256,bytes,classification,state,
                target_project,patch_id,received_utc,vault_path,manifest_json,error
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                item["intake_id"], item["source_name"], item["original_path"], item["sha256"], item["bytes"],
                item["classification"], item["state"], item["target_project"], item["patch_id"], item["received_utc"],
                item["vault_path"], json.dumps(item.get("manifest") or {}, separators=(",", ":"), sort_keys=True), item.get("error") or "",
            ),
        )
        db.commit()
    finally:
        db.close()


def ingest_patch(source: Path, *, remove_source: bool = True) -> dict[str, Any]:
    source = source.expanduser().resolve()
    details = inspect_patch(source)
    digest = sha256_file(source)
    if _already_ingested(digest):
        raise IntakeError("byte-identical patch is already queued/applied")

    intake_id = f"{datetime.now().strftime('%Y%m%d-%H%M%S')}-{uuid.uuid4().hex[:10]}"
    quarantine = vault_root() / "intake" / "quarantine" / intake_id
    quarantine.mkdir(parents=True, exist_ok=True)
    staged = quarantine / source.name
    temp = quarantine / (source.name + ".copying")
    shutil.copy2(source, temp)
    copied_digest = sha256_file(temp)
    if copied_digest != digest:
        temp.unlink(missing_ok=True)
        raise IntakeError("Vault quarantine copy hash mismatch")
    os.replace(temp, staged)

    project = details["project"] or "unassigned"
    safe_project = re.sub(r"[^A-Za-z0-9._-]+", "-", project).strip("-") or "unassigned"
    safe_patch = re.sub(r"[^A-Za-z0-9._-]+", "-", details["patchId"]).strip("-") or intake_id
    queued_dir = vault_root() / "patches" / "queued" / safe_project / safe_patch
    queued_dir.mkdir(parents=True, exist_ok=True)
    queued = queued_dir / source.name
    if queued.exists():
        queued = queued_dir / f"{intake_id}_{source.name}"
    os.replace(staged, queued)
    # Preserve durable transport evidence beside the queued package.
    Path(str(queued) + ".sha256").write_text(f"{digest}  {queued.name}\n", encoding="ascii")
    (queued_dir / "manifest.json").write_text(json.dumps(details["manifest"], indent=2, sort_keys=True) + "\n", encoding="utf-8")
    try:
        quarantine.rmdir()
    except OSError:
        pass

    item = {
        "schema": "forge.intake.receipt.v1",
        "version": FORGE_INTAKE_VERSION,
        "intake_id": intake_id,
        "source_name": source.name,
        "original_path": str(source),
        "sha256": digest,
        "bytes": source.stat().st_size,
        "classification": "PATCH",
        "state": "QUEUED",
        "target_project": project,
        "patch_id": details["patchId"],
        "received_utc": utc_now(),
        "vault_path": str(queued),
        "manifest": details["manifest"],
        "error": "",
    }
    _persist_item(item)
    _write_receipt(item)

    # Never remove the browser/download copy until the Vault copy is durable and hash-verified.
    if remove_source:
        source.unlink()
        for suffix in (".sha256", ".sha256.txt"):
            sidecar = Path(str(source) + suffix)
            if sidecar.is_file():
                sidecar.unlink()
    return item


def scan_downloads(*, force_stable: bool = False, remove_source: bool = True) -> dict[str, Any]:
    results: list[dict[str, Any]] = []
    skipped: list[dict[str, str]] = []
    errors: list[dict[str, str]] = []
    for root in downloads_roots():
        if not root.is_dir():
            continue
        for path in sorted(root.iterdir()):
            if not path.is_file() or path.suffix.casefold() in TEMP_SUFFIXES:
                continue
            if not looks_like_patch(path):
                continue
            try:
                age = max(0.0, time.time() - path.stat().st_mtime)
                stable_count = _observe(path)
                if not force_stable and (age < DEFAULT_STABLE_SECONDS or stable_count < 2):
                    skipped.append({"path": str(path), "reason": "waiting for download to stabilize"})
                    continue
                results.append(ingest_patch(path, remove_source=remove_source))
            except Exception as exc:
                errors.append({"path": str(path), "error": str(exc)})
    return {
        "schema": "forge.intake.scan.v1",
        "version": FORGE_INTAKE_VERSION,
        "timestampUtc": utc_now(),
        "ingested": results,
        "skipped": skipped,
        "errors": errors,
    }


def list_items(*, state: str | None = None, project: str | None = None) -> list[dict[str, Any]]:
    db = _connect()
    try:
        sql = "SELECT intake_id,source_name,original_path,sha256,bytes,classification,state,target_project,patch_id,received_utc,vault_path,manifest_json,error FROM intake_items"
        where: list[str] = []
        args: list[Any] = []
        if state:
            where.append("state=?"); args.append(state.upper())
        if project:
            where.append("lower(target_project)=lower(?)"); args.append(project)
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY received_utc DESC"
        rows = db.execute(sql, args).fetchall()
        keys = ["intake_id","source_name","original_path","sha256","bytes","classification","state","target_project","patch_id","received_utc","vault_path","manifest_json","error"]
        out: list[dict[str, Any]] = []
        for row in rows:
            item = dict(zip(keys, row))
            try:
                item["manifest"] = json.loads(item.pop("manifest_json"))
            except Exception:
                item["manifest"] = {}; item.pop("manifest_json", None)
            out.append(item)
        return out
    finally:
        db.close()


def counts_for_project(*names: str) -> tuple[int, int]:
    wanted = {name.strip().casefold() for name in names if name and name.strip()}
    db = _connect()
    try:
        rows = db.execute("SELECT target_project,state,error FROM intake_items WHERE state IN ('QUEUED','STAGED','REJECTED','FAILED')").fetchall()
    finally:
        db.close()
    pending = invalid = 0
    for project, state, error in rows:
        project_key = str(project or "").casefold()
        if wanted and project_key not in wanted and project_key != "unassigned":
            continue
        if str(state).upper() in {"QUEUED", "STAGED"}:
            pending += 1
        else:
            invalid += 1
    return pending, invalid


def _project_aliases(root: Path) -> set[str]:
    aliases = {root.name.casefold()}
    try:
        from PCCProjectDiscovery import discover_project_contract_data
        data = discover_project_contract_data(root)
        project = data.get("project") or {}
        for value in (project.get("id"), project.get("name")):
            if value:
                aliases.add(str(value).strip().casefold())
    except Exception:
        pass
    return {x for x in aliases if x}


def _set_item_state(intake_id: str, state: str, *, vault_path_value: str | None = None, error: str = "") -> None:
    db = _connect()
    try:
        if vault_path_value is None:
            db.execute("UPDATE intake_items SET state=?,error=? WHERE intake_id=?", (state, error, intake_id))
        else:
            db.execute("UPDATE intake_items SET state=?,vault_path=?,error=? WHERE intake_id=?", (state, vault_path_value, error, intake_id))
        db.commit()
    finally:
        db.close()


def stage_for_project(root: Path) -> dict[str, Any]:
    root = root.expanduser().resolve()
    aliases = _project_aliases(root)
    items = [item for item in list_items() if item.get("state") in {"QUEUED", "STAGED"}]
    selected = [item for item in items if str(item.get("target_project") or "").casefold() in aliases]
    if not selected:
        return {"staged": 0, "items": [], "root": str(root)}
    inbox = root / "updates" / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    staged_rows: list[dict[str, Any]] = []
    for item in selected:
        source = Path(str(item["vault_path"]))
        if not source.is_file():
            _set_item_state(str(item["intake_id"]), "FAILED", error="queued Vault transport missing")
            raise IntakeError(f"queued Vault transport missing: {source}")
        expected = str(item["sha256"])
        if sha256_file(source) != expected:
            _set_item_state(str(item["intake_id"]), "FAILED", error="queued Vault transport hash mismatch")
            raise IntakeError(f"queued Vault transport hash mismatch: {source}")
        dest = inbox / source.name
        if dest.exists():
            if sha256_file(dest) != expected:
                raise IntakeError(f"project inbox already contains conflicting transport: {dest.name}")
        else:
            temp = inbox / (source.name + ".forge-copying")
            shutil.copy2(source, temp)
            if sha256_file(temp) != expected:
                temp.unlink(missing_ok=True)
                raise IntakeError(f"project inbox copy hash mismatch: {source.name}")
            os.replace(temp, dest)
        Path(str(dest) + ".sha256").write_text(f"{expected}  {dest.name}\n", encoding="ascii")
        _set_item_state(str(item["intake_id"]), "STAGED")
        staged_rows.append({"patchId": item["patch_id"], "source": str(source), "projectInbox": str(dest)})
    return {"staged": len(staged_rows), "items": staged_rows, "root": str(root)}


def _applied_patch_ids(root: Path) -> set[str]:
    folders = [
        root / "artifacts" / "patches" / "receipts",
        root / "updates" / "receipts",
        root / ".project_control" / "receipts",
        root / ".cortex" / "patches" / "receipts",
    ]
    found: set[str] = set()
    for folder in folders:
        if not folder.is_dir():
            continue
        for path in folder.glob("*.json"):
            try:
                data = json.loads(path.read_text(encoding="utf-8-sig"))
            except Exception:
                continue
            state = str(data.get("status") or data.get("result") or "").casefold()
            if state not in {"applied", "pass", "success", "green"}:
                continue
            patch_id = str(data.get("patchId") or data.get("patch_id") or "").strip()
            if patch_id:
                found.add(patch_id.casefold())
    return found


def reconcile_project(root: Path) -> dict[str, Any]:
    root = root.expanduser().resolve()
    aliases = _project_aliases(root)
    applied = _applied_patch_ids(root)
    if not applied:
        return {"reconciled": 0, "items": [], "root": str(root)}
    changed: list[dict[str, Any]] = []
    for item in list_items():
        if item.get("state") not in {"QUEUED", "STAGED"}:
            continue
        if str(item.get("target_project") or "").casefold() not in aliases:
            continue
        if str(item.get("patch_id") or "").casefold() not in applied:
            continue
        source = Path(str(item["vault_path"]))
        target_dir = vault_root() / "patches" / "applied" / re.sub(r"[^A-Za-z0-9._-]+", "-", str(item["target_project"])) / re.sub(r"[^A-Za-z0-9._-]+", "-", str(item["patch_id"]))
        target_dir.parent.mkdir(parents=True, exist_ok=True)
        source_dir = source.parent
        if source_dir.exists():
            if target_dir.exists():
                target_dir = target_dir.with_name(target_dir.name + "-" + str(item["intake_id"])[-6:])
            shutil.move(str(source_dir), str(target_dir))
            new_path = target_dir / source.name
        else:
            new_path = source
        _set_item_state(str(item["intake_id"]), "APPLIED", vault_path_value=str(new_path))
        changed.append({"patchId": item["patch_id"], "vaultPath": str(new_path)})
    return {"reconciled": len(changed), "items": changed, "root": str(root)}


def watch(*, interval: float = 3.0) -> int:
    try:
        while True:
            result = scan_downloads()
            for item in result["ingested"]:
                print(f"[PASS] QUEUED {item['patch_id']} -> {item['vault_path']}", flush=True)
            for item in result["errors"]:
                print(f"[WARN] intake rejected {item['path']}: {item['error']}", flush=True)
            time.sleep(max(1.0, interval))
    except KeyboardInterrupt:
        return 0


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Forge Downloads/Vault intake service")
    sub = parser.add_subparsers(dest="command", required=True)
    scan = sub.add_parser("scan")
    scan.add_argument("--force-stable", action="store_true")
    scan.add_argument("--keep-source", action="store_true")
    watch_p = sub.add_parser("watch")
    watch_p.add_argument("--interval", type=float, default=3.0)
    list_p = sub.add_parser("list")
    list_p.add_argument("--state")
    list_p.add_argument("--project")
    ns = parser.parse_args(argv)
    if ns.command == "scan":
        payload = scan_downloads(force_stable=ns.force_stable, remove_source=not ns.keep_source)
        print(json.dumps(payload, indent=2, sort_keys=True))
        return 1 if payload["errors"] else 0
    if ns.command == "watch":
        return watch(interval=ns.interval)
    print(json.dumps(list_items(state=ns.state, project=ns.project), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
