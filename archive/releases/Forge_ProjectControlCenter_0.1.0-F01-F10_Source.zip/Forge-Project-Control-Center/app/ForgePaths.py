#!/usr/bin/env python3
from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable

FORGE_PATHS_VERSION = "FORGE-PATHS-0.1"


def _configured_path(name: str) -> Path | None:
    raw = str(os.environ.get(name) or "").strip()
    if not raw:
        return None
    return Path(raw).expanduser().resolve()


def data_root() -> Path:
    override = _configured_path("FORGE_DATA_ROOT")
    if override is not None:
        return override
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
        return base / "Forge"
    base = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    return base / "forge"


def registry_path() -> Path:
    override = _configured_path("FORGE_PROJECT_REGISTRY")
    if override is not None:
        return override
    return data_root() / "project_registry.json"


def legacy_registry_path() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA") or Path.home() / "AppData" / "Local")
        return base / "ProjectControlCenter" / "project_registry.json"
    base = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config")
    return base / "project-control-center" / "project_registry.json"


def vault_root() -> Path:
    override = _configured_path("FORGE_VAULT_ROOT")
    if override is not None:
        return override
    # Forge is local-first.  On the user's normal Windows workstation, prefer the
    # large D: data drive automatically; portable/fallback machines remain valid.
    if os.name == "nt":
        d_drive = Path("D:/")
        if d_drive.exists():
            return d_drive / "Forge" / "Vault"
    return data_root() / "Vault"


def downloads_roots() -> tuple[Path, ...]:
    raw = str(os.environ.get("FORGE_INTAKE_PATHS") or "").strip()
    candidates: list[Path] = []
    if raw:
        for item in raw.split(os.pathsep):
            item = item.strip()
            if item:
                candidates.append(Path(item).expanduser())
    else:
        candidates.append(Path.home() / "Downloads")

    unique: list[Path] = []
    seen: set[str] = set()
    for path in candidates:
        try:
            normalized = os.path.normcase(str(path.resolve()))
        except Exception:
            normalized = os.path.normcase(str(path))
        if normalized not in seen:
            seen.add(normalized)
            unique.append(path)
    return tuple(unique)


def ensure_dirs(paths: Iterable[Path]) -> None:
    for path in paths:
        path.mkdir(parents=True, exist_ok=True)
