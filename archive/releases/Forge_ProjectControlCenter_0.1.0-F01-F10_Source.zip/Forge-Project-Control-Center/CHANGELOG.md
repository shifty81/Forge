# Forge Changelog

## FORGE-0.1.0-F01-F10 — 2026-09-09

- Forked the verified PCC-GUI-0.10.2 standalone donor into Forge.
- Added Forge data/Vault path authority and legacy registry adoption.
- Made `ForgeGui.py` canonical and retained `CortexPCCGui.py` only as a compatibility shim.
- Added project Health (`GREEN` / `WARN` / `FAIL`) to Registered Projects.
- Added Forge source-control status with mandatory GitHub/Forgejo visibility.
- Added continuous Downloads patch watcher and explicit Vault scan action.
- Added hash-verified Vault patch queue, receipts, sidecars, staging and applied reconciliation.
- Upgraded the operation host so queued patches are applied before Build/Quick/Fast/Full through the project's proven patch authority.
- Added universal Forge console fallback.
- Added Forge self-host project contract, quality gate and automated smoke tests.
