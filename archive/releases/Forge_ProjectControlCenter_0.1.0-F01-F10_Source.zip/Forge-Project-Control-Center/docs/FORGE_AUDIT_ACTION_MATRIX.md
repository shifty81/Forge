# Forge Audit / Action Matrix

Baseline donor SHA-256:

`c84bd04b6daf2644b8b4a316799a136370a8668a5411bc78e28b448adb21e567` — `ProjectControlCenter_Standalone_PCC-GUI-0.10.2_20260909.zip`

| Capability | Donor state | Forge F01-F10 | Action |
|---|---|---|---|
| Standalone GUI | Strong | Canonical `ForgeGui.py` | KEEP / POLISH |
| Havenwild-style primary actions | Strong | Full Gate + Commit/Push remain primary | KEEP |
| Registered project table | Strong | Added computed Health | KEEP |
| Project discovery | Strong | Reused universal discovery | KEEP / NORMALIZE NAMES |
| Auto adapter | Strong | Reused and extended with Forge queue/source status | KEEP |
| Operation host | Strong | Now stages queued Vault patches before builds/gates | UPGRADED |
| Repo hygiene | Strong | Preserved | KEEP |
| Vault catalog | Strong | Moved to Forge path authority | UPGRADED |
| Downloads monitoring | Missing | Continuous GUI watcher + CLI scan | NEW |
| Patch quarantine/queue | Missing | Hash-verified Forge Vault queue | NEW |
| Patch application | Project-specific | Reuse provider `patch-apply` | DEFER UNIVERSAL ENGINE |
| Patch archive evidence | Mixed | Forge receipt + queued/applied archive | UPGRADED |
| Health aggregation | Partial header-only | Universal GREEN/WARN/FAIL | NEW |
| Git | Project-specific | Forge read/status authority | PARTIAL — WRITE AUTHORITY NEXT |
| GitHub | Project-specific | Mandatory presence detection | PARTIAL — AUTH/API NEXT |
| Forgejo | Missing/inconsistent | Mandatory local-remote detection | PARTIAL — SERVICE/PROVISION NEXT |
| Console fallback | Donor only | Universal `ForgeConsole.py` | NEW |
| Self-host Forge | Missing | `project.control.json` + `ForgeGate.py` | NEW |
| Packaged EXE | Missing | Python portable baseline retained | NEXT MILESTONE |
| Self-updater | Missing | Architecture reserved | NEXT MILESTONE |
| Cortex tool API | Conceptual | Stable spine boundaries established | NEXT MILESTONE |
| Debug-bundle authority | Project-specific | Delegated | ABSORB NEXT |
| Universal GREEN fingerprint | Project-specific | Delegated | ABSORB NEXT |

## Next highest-value passes

F11-F20 should absorb universal Git/GREEN and project-independent patch validation/application from the Cortex/Havenwild donors, add Forgejo/GitHub synchronization state, formalize `forge.command` machine JSON/JSONL APIs, and replace remaining Cortex/PCC internal names without breaking legacy launchers.

F21-F30 should package Forge as the actual Windows application, add `ForgeUpdater`, version-directory switching/rollback, service-style Downloads watcher operation when the GUI is closed, diagnostics/debug-bundle authority, and installer/release certification.
