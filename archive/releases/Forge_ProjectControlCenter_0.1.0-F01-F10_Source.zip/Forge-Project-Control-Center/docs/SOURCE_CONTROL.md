# Forge Source Control Authority

Git, GitHub and a Cortex-owned/local Forgejo service are mandatory parts of the target Forge lifecycle.

F01-F10 adds a Forge-owned read/status authority that detects:

- local Git readiness and working-tree state;
- branch/HEAD and upstream ahead/behind counts;
- GitHub remotes;
- local/Forgejo remotes (`forgejo` remote name, Forgejo host names, localhost, or hosts listed in `FORGE_FORGEJO_HOSTS`).

Missing GitHub or Forgejo remotes currently produce normalization warnings rather than preventing local recovery/build work. Mutation remains delegated to the strongest project provider until Forge's universal GREEN-gated commit/push authority is absorbed and certified.
