# Forge Recovery

If the GUI is damaged, use `ForgeConsole.cmd --root <project-root>`. It uses the same project discovery, BackendClient, operation host, Vault intake and provider path as the GUI.

If the normal launcher fails, run `VerifyForge.cmd`, then `Forge.cmd --console --root <project-root>`.

Legacy `ProjectControlCenter.cmd/.vbs` remain aliases during migration.

Forge persistent registry data is stored outside the extracted application folder. Vault defaults to `D:\Forge\Vault` on a Windows machine with a D: drive, otherwise the Forge user-data directory. Set `FORGE_VAULT_ROOT` to override it explicitly.
