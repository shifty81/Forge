# Forge Patch Lifecycle

Current implemented lifecycle:

```text
Downloads
   ↓
observed complete/stable
   ↓
manifest-bearing ZIP recognized
   ↓
ZIP path-safety validation
   ↓
SHA-256 source hash
   ↓
Vault quarantine copy
   ↓
destination hash verification
   ↓
QUEUED + receipt + canonical .sha256
   ↓
next Build / Quick / Fast / Full
   ↓
stage into <project>/updates/inbox
   ↓
project patch authority: patch-apply
   ↓
project APPLIED receipt
   ↓
Forge reconcile
   ↓
Vault/patches/applied/<project>/<patch>
```

The source Downloads file is removed only after a verified Vault copy is durable.

## Vault layout

```text
<Forge Vault>/
├─ catalog/
│  └─ forge_intake.db
├─ intake/
│  └─ quarantine/
└─ patches/
   ├─ queued/
   ├─ applied/
   └─ receipts/
```

Future states already reserved by the architecture: `rejected`, `failed`, `superseded`, `staging`, `certified` and self-update candidates.
