# Forge Architecture — F01-F10

```text
                         FORGE
              Universal Project Control Center
                         │
        ┌────────────────┼────────────────┐
        │                │                │
      GUI             Console        Headless entry
  ForgeGui.py      ForgeConsole.py   ForgeStandalone.py
        └────────────────┼────────────────┘
                         │
                   shared Forge spine
                         │
 ┌─────────────┬─────────┼──────────┬──────────────┐
 │ Project     │ Health  │ Source   │ Patch/Vault  │
 │ discovery   │         │ control  │ intake       │
 ├─────────────┼─────────┼──────────┼──────────────┤
 │ operation   │ repo    │ catalog  │ compatibility│
 │ host        │ hygiene │          │ providers     │
 └─────────────┴─────────┴──────────┴──────────────┘
```

## Authority split

Forge owns project registration, discovery, operation hosting, Health aggregation, intake watching, Vault queueing, source-control visibility, durable intake receipts and the operator surfaces.

During migration, a selected project's strongest existing provider still owns project-specific build logic, project-specific GREEN semantics and patch mutation. This is intentional: Forge stages the universal transport, then calls the proven project authority rather than silently reproducing its behavior.

The final target replaces those mutation authorities one-by-one with Forge implementations while keeping adapters only for project-specific build/run/test semantics.
