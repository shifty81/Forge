@echo off
setlocal
set "FORGE_HOME=%~dp0"
where py.exe >nul 2>nul
if not errorlevel 1 (
  py.exe -3 "%FORGE_HOME%app\ForgeStandalone.py" --self-test
) else (
  python.exe "%FORGE_HOME%app\ForgeStandalone.py" --self-test
)
set "RC=%ERRORLEVEL%"
echo.
if "%RC%"=="0" (
  echo [PASS] Forge standalone verification passed.
) else (
  echo [FAIL] Forge standalone verification failed with code %RC%.
)
pause
exit /b %RC%
