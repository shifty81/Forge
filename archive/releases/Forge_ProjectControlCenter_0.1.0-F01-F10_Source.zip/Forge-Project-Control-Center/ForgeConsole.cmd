@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "FORGE_HOME=%~dp0"
where py.exe >nul 2>nul
if not errorlevel 1 (
  py.exe -3 "%FORGE_HOME%app\ForgeStandalone.py" --console %*
) else (
  python.exe "%FORGE_HOME%app\ForgeStandalone.py" --console %*
)
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" pause
exit /b %RC%
