#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Any, Sequence

from ForgeHealth import evaluate_project
from VaultIntake import reconcile_project, scan_intake, scan_roots, stage_for_project
from VaultPaths import vault_root
from VaultPatchEngine import restart_marker_path
from ForgePYVersion import VERSION as FORGE_VERSION
from ForgeSourceControl import status as source_status
from PCCSurfaceCommon import BackendClient, ProjectContract, ProjectRegistry, SurfaceError, latest_debug_bundle, open_path

CONSOLE_VERSION = f"FORGEPY-CONSOLE-{FORGE_VERSION}"
PCC_VERSION = "FORGEPY-INTERNAL-PCC-1.0-F797"


def _ansi_enabled() -> bool:
    return sys.stdout.isatty() and str(os.environ.get("NO_COLOR") or "").strip() == ""


def _token(text: str, kind: str) -> str:
    if not _ansi_enabled():
        return text
    colors = {"pass": "\x1b[92m", "fail": "\x1b[91m", "warn": "\x1b[93m", "info": "\x1b[96m"}
    return colors.get(kind, "") + text + "\x1b[0m"


def _line(label: str, value: str) -> str:
    return f" {label:<11}: {value}"


def _pause(label: str = "Press Enter to return to ForgePY PCC...") -> None:
    try:
        input(f"\n{label}")
    except EOFError:
        pass


def _status_lines(root: Path, contract: ProjectContract, backend: BackendClient) -> list[str]:
    try:
        status = backend.status()
    except Exception:
        status = evaluate_project(root, contract).status
    git = status.get("git") or {}
    patches = status.get("patches") or {}
    hygiene = status.get("hygiene") or {}
    source = status.get("sourceControl") or source_status(root)
    health = evaluate_project(root, contract)

    if git.get("gitReady"):
        git_text = "Clean" if git.get("clean") else "Modified"
        branch = str(git.get("branch") or "<none>")
        head = str(git.get("headShort") or "<unborn>")
        git_text = f"{branch} / {git_text} @ {head}"
    else:
        git_text = "Not ready"
    green = "MATCH" if git.get("greenMatch") else ("STALE" if git.get("greenMarker") else "NONE")
    pending = int(patches.get("pending", 0) or 0)
    invalid = int(patches.get("invalid", 0) or 0)
    updates = f"{pending} pending" + (f", {invalid} invalid" if invalid else "")
    return [
        _line("Repository", str(root)),
        _line("Project", f"{contract.name} ({contract.kind})"),
        _line("Health", health.label),
        _line("Git", git_text),
        _line("GREEN", green),
        _line("GitHub", "Configured" if source.get("githubConfigured") else "Needs normalization"),
        _line("ForgeGit", "Configured" if (source.get("forgeGitConfigured") or source.get("internalGitConfigured")) else "Needs normalization"),
        _line("Updates", updates),
        _line("Hygiene", "Clean" if hygiene.get("clean", True) else "WARN"),
        _line("Provider", backend.provider_label),
        _line("Vault", str(vault_root())),
    ]


def _run_backend(backend: BackendClient, command: str, extra: Sequence[str] = ()) -> int:
    if not backend.supports(command):
        print(f"[{_token('FAIL', 'fail')}] Command is not supported by this project: {command}")
        return 2
    proc = backend.popen(command, extra)
    assert proc.stdout is not None
    for line in proc.stdout:
        raw = line.rstrip("\r\n")
        for word, kind in (("PASS", "pass"), ("FAIL", "fail"), ("GREEN", "pass"), ("WARN", "warn")):
            if _ansi_enabled() and word in raw:
                raw = raw.replace(word, _token(word, kind))
        print(raw)
    return int(proc.wait())


def _run_if_supported(backend: BackendClient, command: str) -> int:
    if not backend.supports(command):
        print(f"[{_token('INFO', 'info')}] This project does not currently expose '{command}'.")
        return 2
    return _run_backend(backend, command)


def _apply_updates(root: Path, backend: BackendClient) -> int:
    staged = stage_for_project(root)
    count = int(staged.get("staged", 0) or 0)
    print(f"[{_token('INFO', 'info')}] Vault staged {count} queued patch(es) for this project.")
    if count <= 0:
        return 0
    rc = _run_backend(backend, "patch-apply")
    if rc == 0:
        result = reconcile_project(root)
        print(f"[{_token('PASS', 'pass')}] Reconciled {result.get('reconciled', 0)} applied patch(es) into Vault Library.")
        if restart_marker_path().is_file():
            print(f"[{_token('WARN', 'warn')}] ForgePY itself was updated. Exit and reopen ForgePY PCC to load the new application version.")
    return rc


def _startup_root_drop(root: Path, backend: BackendClient) -> None:
    """Ingest only trusted transports physically dropped into the selected project root.

    Downloads remains catalog-only and is never implicitly executed by this startup path.
    """
    try:
        result = scan_roots((root,), force_stable=True, remove_source=True, trusted_roots=(root,))
    except Exception as exc:
        print(f"[{_token('WARN', 'warn')}] Root patch scan could not complete: {exc}")
        return
    queued = [row for row in result.get("ingested", []) if str(row.get("state") or "").upper() == "QUEUED"]
    errors = list(result.get("errors") or [])
    if errors:
        for row in errors[:8]:
            print(f"[{_token('FAIL', 'fail')}] Root intake rejected {row.get('path')}: {row.get('error')}")
    if not queued:
        return
    print(f"[{_token('PASS', 'pass')}] Startup root scan queued {len(queued)} trusted patch transport(s).")
    for row in queued[:12]:
        print(f"  PATCH {row.get('patch_id') or row.get('source_name') or '<unknown>'}")
    try:
        choice = input("Apply queued update(s) now? [y/N]: ").strip().casefold()
    except EOFError:
        choice = ""
    if choice in {"y", "yes"}:
        _apply_updates(root, backend)
    else:
        print(f"[{_token('INFO', 'info')}] Queued patches remain pending for explicit Apply Updates.")


def _registered_commands(contract: ProjectContract) -> None:
    if not contract.commands:
        print("No registered commands discovered.")
        return
    print("\n REGISTERED COMMANDS")
    print("-" * 90)
    for idx, cmd in enumerate(contract.commands, 1):
        category = cmd.category or "other"
        print(f" {idx:>2}. {cmd.key:<30} {cmd.label:<38} [{category}/{cmd.risk}]")


def _choose_project(registry: ProjectRegistry, current: Path) -> Path:
    entries = [entry for entry in registry.entries() if entry.root.is_dir()]
    if not entries:
        print("No other registered projects.")
        return current
    print("\n REGISTERED PROJECTS")
    print("-" * 90)
    for index, entry in enumerate(entries, 1):
        marker = "*" if entry.root.resolve() == current.resolve() else " "
        print(f" {index:>2}. {marker} {entry.name:<24} {entry.root}")
    raw = input("Select project [Enter=cancel]: ").strip()
    if not raw:
        return current
    try:
        selected = entries[int(raw) - 1]
    except Exception:
        print(f"[{_token('WARN', 'warn')}] Invalid selection.")
        return current
    registry.touch(selected.root)
    return selected.root.resolve()


def _header(root: Path, contract: ProjectContract, backend: BackendClient) -> None:
    os.system("cls" if os.name == "nt" else "clear")
    print("=" * 90)
    print(" FORGEPY PROJECT CONTROL CENTER")
    print(f" {PCC_VERSION}  |  ForgePY v{FORGE_VERSION}")
    print("=" * 90)
    for line in _status_lines(root, contract, backend):
        print(line)
    print("-" * 90)
    print("  1. FULL QUALITY GATE / CERTIFY GREEN")
    print("  2. COMMIT + PUSH CURRENT GREEN")
    print()
    print("  3. Run ForgePY GUI")
    print("  4. Development gates / build / tests")
    print("  5. Forge Native / Rust development lane")
    print("  6. Source control & recovery")
    print("  7. Patch / update intake")
    print("  8. Diagnostics & maintenance")
    print("  9. Registered project commands / raw CLI")
    print(" 10. Switch registered project")
    print(" 11. Open project root")
    print("  0. Exit")
    print("-" * 90)


def _development_menu(backend: BackendClient) -> None:
    while True:
        print("\n DEVELOPMENT GATES")
        print(" 1. Quick gate")
        print(" 2. Build / syntax verify")
        print(" 3. ForgePY self-test")
        print(" 4. Unit test suite")
        print(" 5. Refresh package manifest")
        print(" 6. Build distribution package")
        print(" 0. Back")
        choice = input("Select: ").strip()
        if choice == "0": return
        mapping = {
            "1": "quick", "2": "build", "3": "self-test",
            "4": "tests.unit", "5": "manifest.refresh", "6": "package.distribution",
        }
        command = mapping.get(choice)
        if command:
            _run_if_supported(backend, command)
            _pause()


def _rust_menu(backend: BackendClient) -> None:
    while True:
        print("\n FORGE NATIVE / RUST LANE")
        print(" 1. Rust successor status")
        print(" 2. Build Rust Forge")
        print(" 3. Test Rust Forge")
        print(" 4. Rust SHADOW gate")
        print(" 5. Rust parity matrix")
        print(" 6. Rust evidence receipt")
        print(" 7. Rust shell model")
        print(" 8. Rust project intelligence")
        print(" 9. Run Rust Forge")
        print(" 0. Back")
        choice = input("Select: ").strip()
        if choice == "0": return
        mapping = {
            "1": "audit.rust-migration", "2": "build.rust-forge", "3": "test.rust-forge",
            "4": "gate.rust-shadow", "5": "audit.rust-parity", "6": "audit.rust-evidence",
            "7": "audit.rust-shell", "8": "audit.rust-intelligence", "9": "run.rust-forge",
        }
        command = mapping.get(choice)
        if command:
            _run_if_supported(backend, command)
            _pause()


def _source_menu(backend: BackendClient) -> None:
    while True:
        print("\n SOURCE CONTROL & RECOVERY")
        print(" 1. Git status")
        print(" 2. Git review")
        print(" 3. Git history")
        print(" 4. Commit certified GREEN only")
        print(" 5. Push current branch")
        print(" 6. Pull fast-forward only")
        print(" 7. Commit + push certified GREEN")
        print(" 8. Verify repository/source authority")
        print(" 0. Back")
        choice = input("Select: ").strip()
        if choice == "0": return
        mapping = {
            "1": "git-status", "2": "git-review", "3": "git-history",
            "4": "commit-green", "5": "push", "6": "git-pull",
            "7": "commit-push-green", "8": "git-verify",
        }
        command = mapping.get(choice)
        if command:
            _run_if_supported(backend, command)
            _pause()


def _patch_menu(root: Path, backend: BackendClient) -> None:
    while True:
        print("\n PATCH / UPDATE INTAKE")
        print(" 1. Patch status")
        print(" 2. Scan project root for trusted patch transports")
        print(" 3. Scan Vault intake / Downloads catalog")
        print(" 4. Apply queued updates (transactional + Full Gate)")
        print(" 5. Open Vault")
        print(" 0. Back")
        choice = input("Select: ").strip()
        if choice == "0": return
        if choice == "1":
            _run_if_supported(backend, "patch-status")
        elif choice == "2":
            _startup_root_drop(root, backend)
        elif choice == "3":
            result = scan_intake(extra_roots=(root,), force_stable=True, remove_source=True)
            summary = {
                "queued": sum(1 for x in result["ingested"] if str(x.get("state", "")).upper() == "QUEUED"),
                "available": sum(1 for x in result["ingested"] if str(x.get("state", "")).upper() == "AVAILABLE"),
                "review": len(result.get("reviews") or []) + sum(1 for x in result["ingested"] if str(x.get("state", "")).upper() == "REVIEW"),
                "waiting": len(result["skipped"]),
                "blockingErrors": len(result["errors"]),
            }
            print(json.dumps(summary, indent=2))
            print(f"Vault: {vault_root()}")
        elif choice == "4":
            _apply_updates(root, backend)
        elif choice == "5":
            open_path(vault_root())
        _pause()


def _diagnostics_menu(root: Path, backend: BackendClient) -> None:
    while True:
        print("\n DIAGNOSTICS & MAINTENANCE")
        print(" 1. Doctor / project health")
        print(" 2. Toolchain doctor")
        print(" 3. Missing-tool install plan")
        print(" 4. Repository hygiene audit")
        print(" 5. Repair repository transport hygiene")
        print(" 6. Package debug/support bundle")
        print(" 7. Verify latest debug/support bundle")
        print(" 8. Open latest debug bundle")
        print(" 9. Show machine-readable status JSON")
        print(" 0. Back")
        choice = input("Select: ").strip()
        if choice == "0": return
        if choice == "1": _run_if_supported(backend, "doctor")
        elif choice == "2": _run_if_supported(backend, "toolchain.doctor")
        elif choice == "3": _run_if_supported(backend, "toolchain.install-plan")
        elif choice == "4": _run_if_supported(backend, "root-hygiene")
        elif choice == "5": _run_if_supported(backend, "root-hygiene-fix")
        elif choice == "6": _run_if_supported(backend, "debug-bundle")
        elif choice == "7": _run_if_supported(backend, "verify-latest-debug")
        elif choice == "8":
            latest = latest_debug_bundle(root)
            if latest: open_path(latest)
            else: print("No debug bundle found.")
        elif choice == "9":
            try: print(json.dumps(backend.status(), indent=2, sort_keys=True))
            except Exception as exc: print(f"[{_token('FAIL', 'fail')}] {exc}")
        _pause()


def run_console(initial_root: Path) -> int:
    registry = ProjectRegistry()
    root = initial_root.resolve()
    startup_checked: set[str] = set()
    while True:
        try:
            contract = ProjectContract.load(root)
            backend = BackendClient(root, contract)
        except Exception as exc:
            print(f"[{_token('FAIL', 'fail')}] ForgePY could not bind project authority: {exc}")
            return 1
        key = os.path.normcase(str(root))
        if key not in startup_checked:
            startup_checked.add(key)
            _startup_root_drop(root, backend)
        _header(root, contract, backend)
        choice = input("Select an option: ").strip()
        if choice == "0": return 0
        if choice == "1": _run_backend(backend, "full")
        elif choice == "2": _run_backend(backend, "commit-push-green")
        elif choice == "3": _run_backend(backend, "launch-gui")
        elif choice == "4": _development_menu(backend)
        elif choice == "5": _rust_menu(backend)
        elif choice == "6": _source_menu(backend)
        elif choice == "7": _patch_menu(root, backend)
        elif choice == "8": _diagnostics_menu(root, backend)
        elif choice == "9":
            _registered_commands(contract)
            raw = input("Command key [Enter=back]: ").strip()
            if raw: _run_backend(backend, raw)
        elif choice == "10":
            root = _choose_project(registry, root)
            continue
        elif choice == "11":
            open_path(root)
        else:
            print(f"[{_token('WARN', 'warn')}] Unknown option.")
        _pause()


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(description="ForgePY universal internal Project Control Center")
    ap.add_argument("--root", required=True)
    ap.add_argument("--command", help="Run one backend command non-interactively")
    ap.add_argument("--self-test", action="store_true")
    return ap


def main(argv: Sequence[str] | None = None) -> int:
    ns = build_parser().parse_args(argv)
    root = Path(ns.root).expanduser().resolve()
    contract = ProjectContract.load(root)
    backend = BackendClient(root, contract)
    if ns.self_test:
        print(f"PASS pcc-version={PCC_VERSION}")
        print(f"PASS console-version={CONSOLE_VERSION}")
        print(f"PASS project={contract.project_id}")
        print(f"PASS provider={backend.provider_label}")
        print(f"PASS commands={len(contract.commands)}")
        return 0
    if ns.command:
        return _run_backend(backend, ns.command)
    return run_console(root)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (SurfaceError, KeyboardInterrupt) as exc:
        if isinstance(exc, KeyboardInterrupt):
            raise SystemExit(130)
        print(f"FAIL: {exc}", file=sys.stderr)
        raise SystemExit(1)
