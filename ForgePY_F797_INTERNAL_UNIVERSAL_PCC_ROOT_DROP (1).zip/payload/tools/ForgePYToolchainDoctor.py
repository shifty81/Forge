#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
if str(APP) not in sys.path:
    sys.path.insert(0, str(APP))

from ForgeToolchainDoctor import bootstrap_plan, inspect  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description="ForgePY PCC toolchain doctor")
    ap.add_argument("action", choices=("status", "install-plan"))
    ns = ap.parse_args()
    if ns.action == "install-plan":
        plan = bootstrap_plan()
        if not plan:
            print("[PASS] No missing installable toolchains detected.")
            return 0
        print("[INFO] Suggested toolchain bootstrap commands (review before running):")
        for row in plan:
            print(f"  {row['tool']:<12} {row['command']}")
        return 0
    data = inspect()
    print(f"[INFO] Toolchains ready: {data.get('ready', 0)}; missing: {data.get('missing', 0)}")
    for row in data.get("rows", []):
        state = "PASS" if row.get("ready") else "MISS"
        detail = row.get("path") or row.get("wingetId") or "not found"
        print(f"[{state}] {row.get('tool', ''):<12} {detail}")
    print("TOOLCHAIN_DOCTOR_JSON=" + json.dumps(data, separators=(",", ":"), sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
