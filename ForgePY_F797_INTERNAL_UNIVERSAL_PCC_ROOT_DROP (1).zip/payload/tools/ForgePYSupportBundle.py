#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
if str(APP) not in sys.path:
    sys.path.insert(0, str(APP))

from ForgeSupportBundle import create  # noqa: E402


def _latest(root: Path) -> Path | None:
    candidates: list[Path] = []
    for folder in (root / "artifacts" / "debug", root / "artifacts" / "support", root / "logs"):
        if folder.is_dir():
            candidates.extend(folder.glob("*.zip"))
    if not candidates:
        return None
    return max(candidates, key=lambda p: p.stat().st_mtime)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def create_bundle(root: Path) -> int:
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    destination = root / "artifacts" / "support" / f"ForgePY_SupportBundle_{stamp}.zip"
    path = create(root, destination, extra={"source": "ForgePY internal PCC"})
    digest = _sha256(path)
    Path(str(path) + ".sha256").write_text(f"{digest}  {path.name}\n", encoding="ascii")
    print(f"[PASS] Support bundle: {path}")
    print(f"[PASS] SHA-256: {digest}")
    return 0


def verify_latest(root: Path) -> int:
    path = _latest(root)
    if path is None:
        print("[FAIL] No support/debug bundle found.")
        return 2
    try:
        with zipfile.ZipFile(path, "r") as archive:
            broken = archive.testzip()
            names = archive.namelist()
    except Exception as exc:
        print(f"[FAIL] Bundle cannot be opened: {path}: {exc}")
        return 1
    if broken:
        print(f"[FAIL] Bundle member failed CRC: {broken}")
        return 1
    print(f"[PASS] Latest bundle verified: {path}")
    print(f"[PASS] Members: {len(names)}")
    print(f"[PASS] SHA-256: {_sha256(path)}")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description="ForgePY PCC support/debug bundle helper")
    ap.add_argument("action", choices=("create", "verify-latest"))
    ap.add_argument("--root", required=True)
    ns = ap.parse_args()
    root = Path(ns.root).expanduser().resolve()
    if not root.is_dir():
        print(f"[FAIL] Project root does not exist: {root}")
        return 2
    return create_bundle(root) if ns.action == "create" else verify_latest(root)


if __name__ == "__main__":
    raise SystemExit(main())
