from __future__ import annotations

import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ForgePYInternalPCCTests(unittest.TestCase):
    def test_dedicated_pcc_launcher_exists_without_replacing_gui_launcher(self) -> None:
        pcc = (ROOT / "ForgePCC.cmd").read_text(encoding="utf-8")
        self.assertIn("app\\ForgeConsole.py", pcc)
        contract = json.loads((ROOT / "project.control.json").read_text(encoding="utf-8"))
        self.assertEqual(contract["root_control_center"]["launcher"], "ForgePY.cmd")
        self.assertEqual(contract["root_control_center"]["internalPccLauncher"], "ForgePCC.cmd")

    def test_pcc_keeps_full_gate_and_green_push_as_primary_actions(self) -> None:
        source = (ROOT / "app" / "ForgeConsole.py").read_text(encoding="utf-8")
        self.assertIn("FULL QUALITY GATE / CERTIFY GREEN", source)
        self.assertIn("COMMIT + PUSH CURRENT GREEN", source)
        self.assertIn('"commit-push-green"', source)

    def test_pcc_has_development_source_patch_and_diagnostics_menus(self) -> None:
        source = (ROOT / "app" / "ForgeConsole.py").read_text(encoding="utf-8")
        for token in (
            "DEVELOPMENT GATES",
            "FORGE NATIVE / RUST LANE",
            "SOURCE CONTROL & RECOVERY",
            "PATCH / UPDATE INTAKE",
            "DIAGNOSTICS & MAINTENANCE",
            "Registered project commands / raw CLI",
        ):
            self.assertIn(token, source)

    def test_startup_patch_scan_is_root_trusted_and_explicit_apply(self) -> None:
        source = (ROOT / "app" / "ForgeConsole.py").read_text(encoding="utf-8")
        self.assertIn("trusted_roots=(root,)", source)
        self.assertIn("Apply queued update(s) now? [y/N]", source)
        self.assertIn("Downloads remains catalog-only", source)

    def test_contract_exposes_dev_and_rust_tools(self) -> None:
        contract = json.loads((ROOT / "project.control.json").read_text(encoding="utf-8"))
        keys = {row["key"] for row in contract["commands"]}
        required = {
            "gate.full",
            "gate.fast",
            "build.native",
            "tests.unit",
            "manifest.refresh",
            "package.distribution",
            "diagnostics.bundle",
            "diagnostics.verify-latest",
            "repo.audit",
            "maintenance.hygiene",
            "toolchain.doctor",
            "toolchain.install-plan",
            "audit.rust-migration",
            "build.rust-forge",
            "test.rust-forge",
            "run.rust-forge",
            "audit.rust-parity",
            "gate.rust-shadow",
            "audit.rust-evidence",
        }
        self.assertTrue(required.issubset(keys), sorted(required - keys))

    def test_support_bundle_helper_is_registered(self) -> None:
        self.assertTrue((ROOT / "tools" / "ForgePYSupportBundle.py").is_file())


if __name__ == "__main__":
    unittest.main()
