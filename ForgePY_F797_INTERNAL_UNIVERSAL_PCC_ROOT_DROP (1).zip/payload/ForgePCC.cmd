@echo off
setlocal EnableExtensions DisableDelayedExpansion
chcp 65001 >nul 2>nul
set "FORGEPY_ROOT=%~dp0"
set "FORGEPY_PCC=%FORGEPY_ROOT%app\ForgeConsole.py"

where python.exe >nul 2>nul
if not errorlevel 1 (
  python.exe "%FORGEPY_PCC%" --root "%FORGEPY_ROOT%" %*
  exit /b %ERRORLEVEL%
)
where py.exe >nul 2>nul
if not errorlevel 1 (
  py.exe -3 "%FORGEPY_PCC%" --root "%FORGEPY_ROOT%" %*
  exit /b %ERRORLEVEL%
)
echo [FAIL] ForgePY internal PCC requires Python 3.
pause
exit /b 1
