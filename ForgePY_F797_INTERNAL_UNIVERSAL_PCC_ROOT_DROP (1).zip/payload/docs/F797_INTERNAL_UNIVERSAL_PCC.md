# ForgePY internal universal PCC

ForgePY remains the Python compatibility/build surface while active product development moves to Forge Native. This pass gives ForgePY a project-owned CLI Project Control Center without replacing the existing GUI launcher or breaking the historical ForgePY launcher contracts.

## Entry points

- `ForgePY.cmd` — normal ForgePY GUI launcher, preserved for compatibility.
- `ForgePYConsole.cmd` — existing console launcher, now reaches the upgraded PCC console through the normal bootstrap path.
- `ForgePCC.cmd` — direct dedicated internal PCC launcher.

The project contract keeps `root_control_center.launcher = ForgePY.cmd` for the frozen F797 compatibility contract and adds `internalPccLauncher = ForgePCC.cmd`.

## Primary workflow

1. **FULL QUALITY GATE / CERTIFY GREEN**
2. **COMMIT + PUSH CURRENT GREEN**

The GREEN commit path remains fail-closed: source must match the latest certified Full Gate before the commit is created. Commit and push remain separate provider operations underneath the one convenience action.

## PCC tool groups

### Development gates

- Quick gate
- Build / syntax verify
- ForgePY self-test
- Unit test suite
- Package manifest refresh
- Distribution package build

### Forge Native / Rust lane

- Rust successor status
- Rust build
- Rust tests
- Rust SHADOW gate
- Rust parity matrix
- Rust evidence receipt
- Rust shell model
- Rust Project Intelligence
- Run Rust Forge

### Source control & recovery

- Git status
- Git review
- Git history
- Commit certified GREEN
- Push current branch
- Pull fast-forward only
- Commit + push certified GREEN
- Repository/source authority verification

### Patch/update intake

- Patch status
- Trusted project-root scan
- Vault/Downloads catalog scan
- Transactional Apply Updates followed by authoritative Full Gate
- Open Vault

Startup scanning only trusts transports physically dropped into the selected project root. Downloads remains catalog-only and is never implicitly executed by the startup path.

### Diagnostics & maintenance

- Project doctor/health
- Repository hygiene audit
- Repository transport hygiene repair
- Build debug/support bundle
- Verify latest support bundle
- Open latest debug bundle
- Machine-readable status JSON

## Support bundle helper

`tools/ForgePYSupportBundle.py` adds CLI `create` and `verify-latest` actions and writes SHA-256 sidecars for generated support bundles.

## Compatibility rule

This is a ForgePY operations/preservation pass, not a new Python product architecture. New Forge GUI/product development continues in Forge Native. ForgePY stays useful as the build, gate, compatibility, recovery, and fallback console behind the Rust application.

### Toolchain doctor

The PCC also exposes a read-only toolchain doctor and a review-only `winget` bootstrap plan. It never installs missing tools automatically; it reports detected paths and suggested commands so the operator can decide what to install.
