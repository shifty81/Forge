ForgePY F1001-F1125 CUMULATIVE FORGEGUI INTEGRATION ROOT DROP

Drop this ZIP into the ForgePY/Forge project root and process it through the project-owned update/PCC lane.

Includes:
- F1001-F1025 ForgeGUI panel/theme contract bridge
- F1026-F1050 semantic icons + shared widget adapter
- F1051-F1075 shared console severity + exact ForgeGUI source hydration
- F1076-F1100 ForgeGUI dependency doctor, exact-pin/dirty-source verification, atomic evidence
- F1101-F1125 PCC-visible ForgeGUI audit/status/verify/sync operations

ForgeGUI donor: v0.4.8 @ 1829f2a7690ecd6eac401c830ec0adeb1c56af47

After apply, run the normal Full Gate.

Useful governed commands:
  python tools/rust/ForgeGuiDoctor.py --root . --write-evidence
  python tools/rust/ForgeGuiSourceSync.py status --root .
  python tools/rust/ForgeGuiSourceSync.py verify --root .
  python tools/rust/ForgeGuiSourceSync.py sync --root .

Normal project operation does not require a hydrated ForgeGUI donor checkout. The checkout is a pinned development/reference cache under ignored .forge state.
