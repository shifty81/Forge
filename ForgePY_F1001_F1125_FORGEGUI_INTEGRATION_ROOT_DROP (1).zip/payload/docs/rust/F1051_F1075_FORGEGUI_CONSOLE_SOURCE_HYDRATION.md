# Forge Native F1051-F1075 — Shared Console Semantics + ForgeGUI Source Hydration

This wave reduces duplicated console semantics and makes the exact ForgeGUI donor source locally hydratable without changing Forge's project-operation authority.

## Console normalization

`native/forge-rs/src/gui/console.rs` now maps Forge's established transcript prefixes into `forge_gui_console::ConsoleLevel`. Forge retains its project-specific Build/Gate/Patch/Git/Doctor filters, command composer and foreground queue. ForgeGUI supplies the reusable severity vocabulary.

## Exact source hydration

`tools/rust/ForgeGuiSourceSync.py` supports:

- `status` — report expected donor revision and current local checkout state.
- `sync` — clone/fetch and detach-checkout exactly `1829f2a7690ecd6eac401c830ec0adeb1c56af47` into `.forge/deps/ForgeGui`.

The destination is already covered by Forge's existing `.forge/` ignore policy, so donor hydration does not dirty governed source. The Cargo manifest remains exact-revision Git-pinned in this wave; switching automatically to the local checkout is deferred until the Windows Cargo gate can certify the path override behavior.

## Authority boundary

Forge/Python ForgePY continue to own Internal PCC discovery, patch/update policy, operation queue, cancellation, Full Gate and GREEN publication. ForgeGUI remains a reusable GUI/provider library.

## Next

F1076-F1100 should introduce ForgeGUI notification records for operation completion/update intake and then begin replacing duplicate per-panel buttons/tables with shared widget adapters in bounded groups.
