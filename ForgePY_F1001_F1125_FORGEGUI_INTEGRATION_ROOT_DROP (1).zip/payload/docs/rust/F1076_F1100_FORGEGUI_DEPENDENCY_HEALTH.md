# F1076-F1100 — ForgeGUI dependency health and drift protection

This wave hardens the ForgeGUI donor relationship without changing project-operation authority.

## Added

- `tools/rust/ForgeGuiDoctor.py`
  - audits the native Cargo dependency pins,
  - verifies ForgeGUI integration tokens in the bridge files,
  - confirms PCC-visible ForgeGUI audit/sync commands,
  - optionally validates the hydrated donor checkout,
  - writes atomic health evidence to `.forge/native/forgegui-health.json`.
- `ForgeGuiSourceSync.py verify`
  - exact revision verification,
  - origin verification,
  - dirty checkout detection,
  - expected-crate/file verification,
  - atomic source evidence at `.forge/native/forgegui-source.json`.
- safer source synchronization
  - refuses non-Git destination collisions,
  - refuses dirty donor worktrees,
  - refuses donor-origin mismatches,
  - uses a filtered/no-checkout clone before exact detached checkout.

## Authority

ForgeGUI remains a presentation/library donor. ForgePY/Internal PCC remains authoritative for build, patch, gate, recovery, Git policy, and GREEN certification.

A missing local ForgeGUI checkout is a warning, not a project failure, because the Rust dependency remains pinned to the exact Git revision.
