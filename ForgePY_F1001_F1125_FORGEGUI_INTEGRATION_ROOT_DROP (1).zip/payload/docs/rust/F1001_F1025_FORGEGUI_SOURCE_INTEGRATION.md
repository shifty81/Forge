# F1001-F1025 — ForgeGUI Source Integration Foundation

Baseline: current Forge repository commit `5aaefbc02b3dad9bcb38375a881895992b4ad21c` (GREEN ForgePY F797 identity, Rust cumulative handoff through F1000).

ForgeGUI donor authority: `shifty81/ForgeGui` commit `1829f2a7690ecd6eac401c830ec0adeb1c56af47`, ForgeGUI 0.4.8 / `forge.gui.v0.4`.

## Purpose

This wave stops Forge native from growing a second independent GUI contract beside ForgeGUI. It intentionally does **not** rewrite the working Forge shell or move project operations into the GUI library. Instead it creates a compatibility seam that can be carried directly into Ember Studio Tools.

## F1001-F1025 results

- Pins `forge_gui_core` to the exact ForgeGUI donor commit. No floating `main`/branch dependency is permitted.
- Maps all 27 Forge `ToolPanel` entries to renderer-neutral ForgeGUI `PanelDefinition` objects with namespaced IDs (`forge.panel.*`).
- Maps Forge permanent shell anchors to ForgeGUI structural host semantics while retaining Forge's permanent top/left/right/bottom/status shell.
- Exposes the current Forge dark/cyan visual language as ForgeGUI `ThemeTokens`; existing Forge constants remain compatibility aliases during migration.
- Keeps project/PCC/operation queue authority in Forge. ForgeGUI supplies reusable UI vocabulary and tokens only.
- Bumps the native GUI contract to `FORGE-NATIVE-HYBRID-SHELL-5.0-F1025` and the panel registry to `FORGE-NATIVE-TOOL-REGISTRY-1.2-F1025`.
- Adds Python regression coverage so ForgePY Full Gate can detect source-contract drift even before the Rust compile stage.

## Why this order

The application already has a coherent hybrid shell. Replacing it wholesale with ForgeGUI would recreate the detached-panel regression. The safe migration is contract-first: theme + panel identity + docking vocabulary, followed by widgets/console/notifications and then deeper dock-runtime unification.

## Next cumulative wave

F1026-F1050 should absorb ForgeGUI widgets, console styling, notifications, icons, shared status/toolbar components, and a local-source/vendor resolver so a normal Forge build does not depend on an online Git fetch once ForgeGUI has been hydrated. Ember Studio Tools can then convert the pinned source boundary to workspace path dependencies.
