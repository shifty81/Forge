# F1101-F1125 — PCC-visible ForgeGUI operations

ForgeGUI integration is now addressable through the same `project.control.json` contract used by ForgePY and Forge Native.

Registered operations:

- `audit.forgegui` — full integration doctor + evidence receipt
- `audit.forgegui-source` — donor checkout status
- `audit.forgegui-source-verify` — exact donor checkout verification
- `tooling.forgegui-source-sync` — governed donor hydration into `.forge/deps/ForgeGui`

The sync command is explicitly marked mutating. The three audit commands are read-only.

This makes ForgeGUI health visible to the project tooling spine instead of requiring ad-hoc manual commands, while retaining the existing certified ForgePY execution route.

## Offline behavior

Normal ForgePY/project operation does not require the donor checkout. A hydrated copy is a development/reference cache. If offline, the doctor reports the missing cache as WARN unless `--require-source` is requested.
