# Forge Native F1026-F1050 — ForgeGUI Widgets + Semantic Icons

This wave continues the F1001-F1025 source-contract bridge without replacing Forge's working hybrid shell or operational authority.

## What changes

- `forge_gui_icons` and `forge_gui_widgets` are pinned to the exact ForgeGUI donor commit `1829f2a7690ecd6eac401c830ec0adeb1c56af47`.
- Forge panel definitions now export stable ForgeGUI semantic icon keys rather than persisting the shell's legacy Unicode display glyphs.
- The host installs the ForgeGUI icon font explicitly, preserving the rule that the host owns font configuration.
- Forge exposes shared icon-button adapters for new/normalized surfaces while existing panel controls remain behavior-compatible.
- Current Forge theme tokens remain the visual authority and continue to feed ForgeGUI's renderer-neutral `ThemeTokens`.

## Authority boundary

ForgeGUI owns reusable presentation vocabulary: panel definitions, semantic icons, widget adapters and theme tokens. Forge continues to own project binding, Internal PCC discovery, patch policy, foreground operations, cancellation, certification and ForgePY compatibility.

## Migration strategy

Do not rewrite all panels at once. New surfaces should use the semantic icon/widget helpers immediately; existing panels can move over incrementally as they are touched. This prevents a visual refactor from destabilizing build/update governance.

## Next wave

F1051-F1075 should adopt shared ForgeGUI console/notification primitives and introduce a local-source resolver so a hydrated ForgeGUI checkout can replace the git source pin for offline/reproducible builds.
