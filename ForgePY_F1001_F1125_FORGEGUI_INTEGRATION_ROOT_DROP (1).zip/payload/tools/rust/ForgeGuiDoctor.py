#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

FORGE_GUI_REV = "1829f2a7690ecd6eac401c830ec0adeb1c56af47"
FORGE_GUI_VERSION = "0.4.8"
FORGE_GUI_DEPS = ("forge_gui_core", "forge_gui_icons", "forge_gui_widgets", "forge_gui_console")
EXPECTED_CONTRACT_COMMANDS = (
    "audit.forgegui",
    "audit.forgegui-source",
    "audit.forgegui-source-verify",
    "tooling.forgegui-source-sync",
)
TOKEN_CHECKS = {
    "native/forge-rs/src/gui/contract.rs": ("FORGE_GUI_API_EXPECTED", "forge.gui.v0.4"),
    "native/forge-rs/src/gui/registry.rs": ("PanelDefinition", "forge_gui_catalog"),
    "native/forge-rs/src/gui/theme.rs": ("ThemeTokens", "forge_gui_widgets"),
    "native/forge-rs/src/gui/console.rs": ("ConsoleLevel",),
}


def _read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except OSError:
        return ""


def _atomic_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, dir=path.parent, suffix=".tmp") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")
        temp_name = handle.name
    os.replace(temp_name, path)


def _check(checks: list[dict[str, str]], name: str, state: str, detail: str) -> None:
    checks.append({"name": name, "state": state, "detail": detail})


def _source_status(root: Path) -> dict[str, Any]:
    script = root / "tools" / "rust" / "ForgeGuiSourceSync.py"
    if not script.is_file():
        return {"ready": False, "checkoutReady": False, "reason": "source-sync tool missing"}
    try:
        result = subprocess.run(
            [sys.executable, str(script), "status", "--root", str(root)],
            check=False,
            capture_output=True,
            text=True,
            timeout=30,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return {"ready": False, "checkoutReady": False, "reason": str(exc)}
    if result.returncode:
        return {"ready": False, "checkoutReady": False, "reason": result.stderr.strip() or result.stdout.strip()}
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        return {"ready": False, "checkoutReady": False, "reason": "invalid source status JSON"}


def audit(root: Path, *, require_source: bool = False) -> tuple[dict[str, Any], int]:
    checks: list[dict[str, str]] = []

    cargo = root / "native" / "forge-rs" / "Cargo.toml"
    cargo_text = _read(cargo)
    if not cargo_text:
        _check(checks, "native-cargo", "FAIL", f"missing {cargo}")
    else:
        _check(checks, "native-cargo", "PASS", "Forge Native Cargo manifest is present")
        for dep in FORGE_GUI_DEPS:
            line = next((line for line in cargo_text.splitlines() if line.strip().startswith(dep + " =")), "")
            if not line:
                _check(checks, f"cargo:{dep}", "FAIL", "dependency is not declared")
            elif FORGE_GUI_REV not in line:
                _check(checks, f"cargo:{dep}", "FAIL", "dependency is not pinned to the certified ForgeGUI revision")
            else:
                _check(checks, f"cargo:{dep}", "PASS", f"pinned to {FORGE_GUI_REV}")

    for rel, tokens in TOKEN_CHECKS.items():
        text = _read(root / rel)
        missing = [token for token in tokens if token not in text]
        if not text:
            _check(checks, f"source:{rel}", "FAIL", "integration file is missing")
        elif missing:
            _check(checks, f"source:{rel}", "FAIL", "missing integration token(s): " + ", ".join(missing))
        else:
            _check(checks, f"source:{rel}", "PASS", "ForgeGUI integration tokens present")

    contract_path = root / "project.control.json"
    contract_text = _read(contract_path)
    try:
        contract = json.loads(contract_text) if contract_text else {}
    except json.JSONDecodeError as exc:
        contract = {}
        _check(checks, "project-contract-json", "FAIL", f"invalid JSON: {exc}")
    if contract:
        keys = {str(row.get("key") or "") for row in contract.get("commands", []) if isinstance(row, dict)}
        missing = [key for key in EXPECTED_CONTRACT_COMMANDS if key not in keys]
        if missing:
            _check(checks, "project-contract-forgegui", "FAIL", "missing PCC commands: " + ", ".join(missing))
        else:
            _check(checks, "project-contract-forgegui", "PASS", "ForgeGUI audit/sync operations are PCC-visible")
    elif not any(row["name"] == "project-contract-json" for row in checks):
        _check(checks, "project-contract-json", "FAIL", "project.control.json is missing")

    source = _source_status(root)
    if source.get("checkoutReady"):
        if source.get("ready"):
            _check(checks, "donor-source", "PASS", "local ForgeGUI donor checkout is exact, clean, and complete")
        else:
            _check(checks, "donor-source", "FAIL", "local ForgeGUI donor checkout exists but failed verification")
    elif require_source:
        _check(checks, "donor-source", "FAIL", "ForgeGUI donor source is required but not hydrated")
    else:
        _check(checks, "donor-source", "WARN", "ForgeGUI donor source is not hydrated; git dependency pin remains authoritative")

    failures = [row for row in checks if row["state"] == "FAIL"]
    warnings = [row for row in checks if row["state"] == "WARN"]
    state = "FAIL" if failures else "WARN" if warnings else "PASS"
    result: dict[str, Any] = {
        "schema": "forge.forgegui-health.v1",
        "forgeGuiVersion": FORGE_GUI_VERSION,
        "forgeGuiRevision": FORGE_GUI_REV,
        "root": str(root),
        "state": state,
        "failureCount": len(failures),
        "warningCount": len(warnings),
        "checks": checks,
        "source": source,
    }
    return result, 1 if failures else 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Audit Forge/ForgePY integration with the pinned ForgeGUI donor")
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--require-source", action="store_true")
    parser.add_argument("--write-evidence", action="store_true")
    args = parser.parse_args()
    root = Path(args.root).expanduser().resolve()
    result, rc = audit(root, require_source=args.require_source)
    if args.write_evidence:
        evidence = root / ".forge" / "native" / "forgegui-health.json"
        _atomic_json(evidence, result)
        result["evidence"] = str(evidence)
    if args.json:
        print(json.dumps(result, indent=2, sort_keys=True))
    else:
        for row in result["checks"]:
            print(f"[{row['state']}] {row['name']}: {row['detail']}")
        print(f"[{result['state']}] ForgeGUI integration health: {result['failureCount']} failure(s), {result['warningCount']} warning(s).")
        if args.write_evidence:
            print(f"[INFO] Evidence: {result['evidence']}")
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
