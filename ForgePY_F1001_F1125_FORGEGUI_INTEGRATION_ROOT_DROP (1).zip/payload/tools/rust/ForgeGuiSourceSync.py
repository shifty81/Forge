#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

FORGE_GUI_URL = "https://github.com/shifty81/ForgeGui.git"
FORGE_GUI_REV = "1829f2a7690ecd6eac401c830ec0adeb1c56af47"
FORGE_GUI_VERSION = "0.4.8"
EXPECTED_FILES = (
    "Cargo.toml",
    "crates/forge_gui_core/Cargo.toml",
    "crates/forge_gui_icons/Cargo.toml",
    "crates/forge_gui_widgets/Cargo.toml",
    "crates/forge_gui_console/Cargo.toml",
    "crates/forge_gui_egui/Cargo.toml",
)


def checkout_path(root: Path) -> Path:
    return root / ".forge" / "deps" / "ForgeGui"


def evidence_path(root: Path) -> Path:
    return root / ".forge" / "native" / "forgegui-source.json"


def _git() -> str:
    return shutil.which("git") or ""


def _git_text(path: Path, *args: str, timeout: int = 30) -> str:
    git = _git()
    if not git or not (path / ".git").exists():
        return ""
    try:
        result = subprocess.run(
            [git, "-C", str(path), *args],
            check=False,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
    except (OSError, subprocess.TimeoutExpired):
        return ""
    return result.stdout.strip() if result.returncode == 0 else ""


def _atomic_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile("w", encoding="utf-8", delete=False, dir=path.parent, suffix=".tmp") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True)
        handle.write("\n")
        temp_name = handle.name
    os.replace(temp_name, path)


def status(root: Path) -> dict[str, object]:
    path = checkout_path(root)
    git = _git()
    head = _git_text(path, "rev-parse", "HEAD")
    remote = _git_text(path, "remote", "get-url", "origin")
    porcelain = _git_text(path, "status", "--porcelain", "--untracked-files=normal")
    missing = [rel for rel in EXPECTED_FILES if not (path / rel).is_file()]
    checkout_ready = (path / ".git").exists()
    revision_ready = head == FORGE_GUI_REV
    remote_ready = remote.rstrip("/") == FORGE_GUI_URL.rstrip("/") if remote else False
    clean = checkout_ready and not porcelain
    expected_ready = checkout_ready and not missing
    ready = bool(git) and checkout_ready and revision_ready and remote_ready and clean and expected_ready
    return {
        "schema": "forge.forgegui-source.v2",
        "url": FORGE_GUI_URL,
        "revision": FORGE_GUI_REV,
        "version": FORGE_GUI_VERSION,
        "checkout": str(path),
        "gitReady": bool(git),
        "checkoutReady": checkout_ready,
        "head": head,
        "revisionReady": revision_ready,
        "remote": remote,
        "remoteReady": remote_ready,
        "dirty": bool(porcelain),
        "clean": clean,
        "expectedFilesReady": expected_ready,
        "missingFiles": missing,
        "ready": ready,
    }


def _run(argv: list[str], *, timeout: int = 300) -> int:
    print("[FORGEGUI] " + " ".join(argv), flush=True)
    try:
        return subprocess.run(argv, check=False, timeout=timeout).returncode
    except subprocess.TimeoutExpired:
        print(f"[FAIL] ForgeGUI source command timed out after {timeout}s.", flush=True)
        return 124
    except OSError as exc:
        print(f"[FAIL] ForgeGUI source command could not start: {exc}", flush=True)
        return 127


def _write_evidence(root: Path) -> dict[str, object]:
    row = status(root)
    _atomic_json(evidence_path(root), row)
    return row


def verify(root: Path, *, quiet: bool = False) -> int:
    row = status(root)
    failures: list[str] = []
    if not row["gitReady"]:
        failures.append("Git is not available on PATH")
    if not row["checkoutReady"]:
        failures.append("ForgeGUI source has not been hydrated")
    if row["checkoutReady"] and not row["remoteReady"]:
        failures.append("ForgeGUI checkout origin does not match the certified donor URL")
    if row["checkoutReady"] and not row["revisionReady"]:
        failures.append(f"ForgeGUI checkout is not pinned to {FORGE_GUI_REV}")
    if row["checkoutReady"] and row["dirty"]:
        failures.append("ForgeGUI donor checkout contains local modifications/untracked files")
    if row["checkoutReady"] and not row["expectedFilesReady"]:
        failures.append("ForgeGUI checkout is missing expected source files")
    _atomic_json(evidence_path(root), row)
    if failures:
        if not quiet:
            for failure in failures:
                print(f"[FAIL] {failure}")
            print(f"[INFO] Evidence: {evidence_path(root)}")
        return 1
    if not quiet:
        print(f"[PASS] ForgeGUI donor source verified: {FORGE_GUI_VERSION} @ {FORGE_GUI_REV}")
        print(f"[INFO] Evidence: {evidence_path(root)}")
    return 0


def sync(root: Path) -> int:
    git = _git()
    if not git:
        print("[FAIL] Git is required to hydrate ForgeGUI source.", flush=True)
        return 2
    dest = checkout_path(root)
    dest.parent.mkdir(parents=True, exist_ok=True)

    if dest.exists() and not (dest / ".git").exists() and any(dest.iterdir()):
        print(f"[FAIL] Refusing to overwrite non-Git directory: {dest}", flush=True)
        return 2

    if (dest / ".git").exists():
        dirty = _git_text(dest, "status", "--porcelain", "--untracked-files=normal")
        if dirty:
            print(f"[FAIL] Refusing to modify dirty ForgeGUI donor checkout: {dest}", flush=True)
            print("[INFO] Preserve/review local donor edits before synchronizing.", flush=True)
            return 2
        remote = _git_text(dest, "remote", "get-url", "origin")
        if remote and remote.rstrip("/") != FORGE_GUI_URL.rstrip("/"):
            print(f"[FAIL] ForgeGUI donor origin mismatch: {remote}", flush=True)
            return 2
    else:
        if dest.exists() and not any(dest.iterdir()):
            dest.rmdir()
        if _run([git, "clone", "--filter=blob:none", "--no-checkout", FORGE_GUI_URL, str(dest)], timeout=900):
            return 1

    if _run([git, "-C", str(dest), "fetch", "--depth", "1", "origin", FORGE_GUI_REV], timeout=900):
        return 1
    if _run([git, "-C", str(dest), "checkout", "--detach", FORGE_GUI_REV], timeout=300):
        return 1

    rc = verify(root, quiet=True)
    row = _write_evidence(root)
    if rc:
        print(f"[FAIL] ForgeGUI source did not verify after synchronization: {row}", flush=True)
        return rc
    print(f"[PASS] ForgeGUI source hydrated and verified at {FORGE_GUI_REV} -> {dest}", flush=True)
    print(f"[INFO] Evidence: {evidence_path(root)}", flush=True)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Hydrate and verify the exact ForgeGUI donor source used by Forge Native")
    parser.add_argument("action", choices=("status", "sync", "verify"), nargs="?", default="status")
    parser.add_argument("--root", default=str(Path(__file__).resolve().parents[2]))
    args = parser.parse_args()
    root = Path(args.root).expanduser().resolve()
    if args.action == "sync":
        return sync(root)
    if args.action == "verify":
        return verify(root)
    print(json.dumps(status(root), indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
