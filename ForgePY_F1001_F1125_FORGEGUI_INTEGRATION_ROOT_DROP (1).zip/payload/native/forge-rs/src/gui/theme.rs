use std::path::PathBuf;

use eframe::egui::{self, Align, Color32, Layout, RichText, Stroke, Theme, Visuals};
use forge_gui_core::{Rgba, ThemeTokens, FORGE_GUI_API_VERSION};
use forge_gui_icons::IconId;

/// Exact ForgeGUI donor source used by this Forge native integration wave.
pub const FORGE_GUI_SOURCE_REV: &str = "1829f2a7690ecd6eac401c830ec0adeb1c56af47";
pub const FORGE_GUI_CONTRACT: &str = FORGE_GUI_API_VERSION;
pub const FORGE_GUI_WIDGETS_BOUND: bool = true;
pub const FORGE_GUI_SEMANTIC_ICONS_BOUND: bool = true;

// Compatibility color names remain available to existing Forge panels, but the
// canonical palette now has a ForgeGUI ThemeTokens representation below.
pub const BG_ROOT: Color32 = Color32::from_rgb(8, 12, 16);
pub const BG_PANEL: Color32 = Color32::from_rgb(12, 18, 23);
pub const BG_PANEL_ALT: Color32 = Color32::from_rgb(15, 22, 28);
pub const BG_SELECTED: Color32 = Color32::from_rgb(14, 31, 39);
pub const BG_INPUT: Color32 = Color32::from_rgb(6, 10, 13);
pub const BORDER: Color32 = Color32::from_rgb(30, 43, 52);
pub const BORDER_STRONG: Color32 = Color32::from_rgb(39, 58, 69);
pub const TEXT: Color32 = Color32::from_rgb(219, 230, 236);
pub const MUTED: Color32 = Color32::from_rgb(130, 151, 162);
pub const CYAN: Color32 = Color32::from_rgb(0, 208, 231);
pub const GREEN: Color32 = Color32::from_rgb(39, 224, 116);
pub const YELLOW: Color32 = Color32::from_rgb(238, 194, 69);
pub const RED: Color32 = Color32::from_rgb(244, 74, 89);

pub const RADIUS_SMALL: u8 = 6;
pub const RADIUS_CONTROL: u8 = 8;
pub const RADIUS_PANEL: u8 = 10;
pub const RADIUS_DIALOG: u8 = 12;

/// Shared renderer-neutral ForgeGUI tokens for the current Forge skin.
///
/// Forge-specific egui details can still layer on top, but portable surfaces now
/// have one token contract that Ember/ForgeGUI can consume without importing the
/// Forge application shell.
pub fn tokens() -> ThemeTokens {
    ThemeTokens {
        background: Rgba(8, 12, 16, 255),
        panel: Rgba(12, 18, 23, 255),
        panel_raised: Rgba(15, 22, 28, 255),
        panel_recessed: Rgba(6, 10, 13, 255),
        border: Rgba(30, 43, 52, 255),
        border_focus: Rgba(0, 208, 231, 255),
        text: Rgba(219, 230, 236, 255),
        text_muted: Rgba(130, 151, 162, 255),
        accent: Rgba(0, 208, 231, 255),
        success: Rgba(39, 224, 116, 255),
        warning: Rgba(238, 194, 69, 255),
        danger: Rgba(244, 74, 89, 255),
        status_height: 24.0,
        toolbar_height: 38.0,
        corner_radius: f32::from(RADIUS_CONTROL),
        scrollbar_width: 10.0,
    }
}

fn color(value: Rgba) -> Color32 {
    Color32::from_rgba_unmultiplied(value.0, value.1, value.2, value.3)
}

pub fn install(ctx: &egui::Context) {
    // Forge owns its font setup; extend the default egui set with the shared
    // ForgeGUI semantic icon family before any panel renders.
    let mut fonts = egui::FontDefinitions::default();
    forge_gui_widgets::add_default_icon_font(&mut fonts);
    ctx.set_fonts(fonts);
    ctx.set_theme(Theme::Dark);
    let tokens = tokens();
    let mut style = (*ctx.style_of(Theme::Dark)).clone();
    let mut visuals = Visuals::dark();
    visuals.panel_fill = color(tokens.background);
    visuals.window_fill = color(tokens.panel);
    visuals.extreme_bg_color = color(tokens.panel_recessed);
    visuals.faint_bg_color = color(tokens.panel_raised);
    visuals.selection.bg_fill = color(tokens.accent);
    visuals.selection.stroke = Stroke::new(1.0, color(tokens.border_focus));
    visuals.window_corner_radius = egui::CornerRadius::same(RADIUS_DIALOG);
    visuals.menu_corner_radius = egui::CornerRadius::same(RADIUS_CONTROL);

    visuals.widgets.noninteractive.bg_fill = color(tokens.panel);
    visuals.widgets.noninteractive.bg_stroke = Stroke::new(1.0, color(tokens.border));
    visuals.widgets.noninteractive.corner_radius = egui::CornerRadius::same(RADIUS_CONTROL);
    visuals.widgets.inactive.bg_fill = color(tokens.panel_raised);
    visuals.widgets.inactive.bg_stroke = Stroke::new(1.0, color(tokens.border));
    visuals.widgets.inactive.corner_radius = egui::CornerRadius::same(RADIUS_CONTROL);
    visuals.widgets.hovered.bg_fill = Color32::from_rgb(21, 37, 45);
    visuals.widgets.hovered.bg_stroke = Stroke::new(1.0, color(tokens.border_focus));
    visuals.widgets.hovered.corner_radius = egui::CornerRadius::same(RADIUS_CONTROL);
    visuals.widgets.active.bg_fill = Color32::from_rgb(0, 79, 91);
    visuals.widgets.active.bg_stroke = Stroke::new(1.0, color(tokens.accent));
    visuals.widgets.active.corner_radius = egui::CornerRadius::same(RADIUS_CONTROL);
    visuals.widgets.open.corner_radius = egui::CornerRadius::same(RADIUS_CONTROL);
    visuals.override_text_color = Some(color(tokens.text));
    style.visuals = visuals;
    style.spacing.item_spacing = egui::vec2(6.0, 6.0);
    style.spacing.button_padding = egui::vec2(10.0, 6.0);
    style.spacing.window_margin = egui::Margin::same(8);
    ctx.set_style_of(Theme::Dark, style);
}

/// Shared semantic icon text backed by ForgeGUI.
pub fn semantic_icon_text(icon: IconId) -> &'static str {
    forge_gui_widgets::icon_text(icon)
}

/// Standard ForgeGUI icon-only button for new native surfaces.
pub fn icon_button(ui: &mut egui::Ui, icon: IconId, tooltip: &str) -> egui::Response {
    forge_gui_widgets::icon_button(ui, icon, tooltip)
}

/// Standard ForgeGUI icon + label button for incremental panel normalization.
pub fn labeled_icon_button(ui: &mut egui::Ui, icon: IconId, label: &str) -> egui::Response {
    forge_gui_widgets::labeled_icon_button(ui, icon, label)
}

fn rounded_frame(fill: Color32, stroke: Stroke, margin: egui::Margin, radius: u8) -> egui::Frame {
    egui::Frame::new()
        .fill(fill)
        .stroke(stroke)
        .inner_margin(margin)
        .corner_radius(egui::CornerRadius::same(radius))
}

pub fn rail_frame() -> egui::Frame {
    rounded_frame(BG_PANEL, Stroke::new(1.0, BORDER_STRONG), egui::Margin::same(8), RADIUS_PANEL)
}

pub fn project_rail_frame() -> egui::Frame {
    rounded_frame(Color32::from_rgb(10, 16, 21), Stroke::new(1.0, BORDER), egui::Margin::same(8), RADIUS_PANEL)
}

pub fn toolbar_frame() -> egui::Frame {
    rounded_frame(Color32::from_rgb(10, 16, 21), Stroke::new(1.0, BORDER_STRONG), egui::Margin::symmetric(8, 7), RADIUS_PANEL)
}

pub fn status_frame() -> egui::Frame {
    rounded_frame(Color32::from_rgb(7, 11, 15), Stroke::new(1.0, BORDER), egui::Margin::symmetric(8, 4), RADIUS_SMALL)
}

pub fn panel_frame() -> egui::Frame {
    rounded_frame(BG_PANEL, Stroke::new(1.0, BORDER), egui::Margin::same(8), RADIUS_PANEL)
}

pub fn card_frame() -> egui::Frame {
    rounded_frame(BG_PANEL_ALT, Stroke::new(1.0, BORDER), egui::Margin::same(10), RADIUS_CONTROL)
}

pub fn identity_chip(ui: &mut egui::Ui, project_name: &str, icon: Option<&PathBuf>) {
    rounded_frame(BG_SELECTED, Stroke::new(1.0, BORDER_STRONG), egui::Margin::symmetric(8, 5), RADIUS_CONTROL).show(ui, |ui| {
        ui.horizontal(|ui| {
            if let Some(icon) = icon {
                let normalized = icon.display().to_string().replace('\\', "/");
                ui.add(egui::Image::new(format!("file://{normalized}")).fit_to_exact_size(egui::vec2(16.0, 16.0)));
            } else {
                let initials: String = project_name.chars().filter(|ch| ch.is_alphanumeric()).take(2).collect();
                ui.label(RichText::new(if initials.is_empty() { "PR".into() } else { initials }).strong().color(CYAN));
            }
            ui.label(RichText::new(format!("{} · PROJECT", project_name)).strong().color(CYAN));
            ui.with_layout(Layout::right_to_left(Align::Center), |_ui| {});
        });
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn forge_palette_is_exposed_through_forgegui_tokens() {
        let t = tokens();
        assert_eq!(FORGE_GUI_CONTRACT, "forge.gui.v0.4");
        assert_eq!(color(t.background), BG_ROOT);
        assert_eq!(color(t.panel), BG_PANEL);
        assert_eq!(color(t.panel_raised), BG_PANEL_ALT);
        assert_eq!(color(t.panel_recessed), BG_INPUT);
        assert_eq!(color(t.accent), CYAN);
        assert_eq!(color(t.success), GREEN);
        assert_eq!(color(t.warning), YELLOW);
        assert_eq!(color(t.danger), RED);
        assert!(FORGE_GUI_WIDGETS_BOUND);
        assert!(FORGE_GUI_SEMANTIC_ICONS_BOUND);
    }

    #[test]
    fn semantic_icons_are_resolved_by_shared_forgegui_widget_adapter() {
        assert!(!semantic_icon_text(IconId::Build).is_empty());
        assert!(!semantic_icon_text(IconId::Project).is_empty());
        assert!(!semantic_icon_text(IconId::Console).is_empty());
    }
}
