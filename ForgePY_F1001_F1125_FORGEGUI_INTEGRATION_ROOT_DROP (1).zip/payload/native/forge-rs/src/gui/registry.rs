use super::model::{ShellAnchor, ToolPanel};
use forge_gui_core::{
    HostMode, InstancePolicy, PanelCatalog, PanelDefinition, PanelRole,
    PanelScope as ForgeGuiPanelScope, PreferredDock,
};
use forge_gui_icons::IconId;

pub const PANEL_REGISTRY_VERSION: &str = "FORGE-NATIVE-TOOL-REGISTRY-1.3-F1050";
pub const FORGE_GUI_SOURCE_REV: &str = "1829f2a7690ecd6eac401c830ec0adeb1c56af47";

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PanelScope {
    Global,
    Project,
    Workspace,
    System,
}

impl PanelScope {
    pub const fn label(self) -> &'static str {
        match self {
            Self::Global => "GLOBAL",
            Self::Project => "PROJECT",
            Self::Workspace => "WORKSPACE",
            Self::System => "SYSTEM",
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum PanelMaturity {
    Native,
    Hybrid,
    Shadow,
}

impl PanelMaturity {
    pub const fn label(self) -> &'static str {
        match self {
            Self::Native => "NATIVE",
            Self::Hybrid => "HYBRID",
            Self::Shadow => "SHADOW",
        }
    }
}

#[derive(Debug, Clone, Copy)]
pub struct PanelDescriptor {
    pub panel: ToolPanel,
    pub id: &'static str,
    pub title: &'static str,
    pub category: &'static str,
    pub summary: &'static str,
    pub scope: PanelScope,
    pub maturity: PanelMaturity,
    pub preferred_size: [f32; 2],
    pub minimum_size: [f32; 2],
    pub singleton: bool,
    pub standalone: bool,
}

macro_rules! d {
    ($panel:ident,$summary:expr,$scope:ident,$maturity:ident,$w:expr,$h:expr) => {
        PanelDescriptor {
            panel: ToolPanel::$panel,
            id: ToolPanel::$panel.slug(),
            title: ToolPanel::$panel.title(),
            category: ToolPanel::$panel.category(),
            summary: $summary,
            scope: PanelScope::$scope,
            maturity: PanelMaturity::$maturity,
            preferred_size: [$w, $h],
            minimum_size: [320.0, 220.0],
            singleton: true,
            standalone: true,
        }
    };
}

pub const PANELS: [PanelDescriptor; 27] = [
    d!(ForgeNavigator, "Primary Forge surface navigator and interface entry point.", Global, Native, 360.0, 640.0),
    d!(ProjectNavigator, "Selected-project capability navigator.", Project, Native, 380.0, 700.0),
    d!(QuickActions, "Compact project build, gate, run and refresh command surface.", Project, Hybrid, 760.0, 260.0),
    d!(Overview, "Project status, authority and primary-operation dashboard.", Project, Hybrid, 900.0, 700.0),
    d!(Source, "Repository, ForgeGit and source-control workspace.", Project, Shadow, 980.0, 720.0),
    d!(BuildTest, "Build, test, quality gate and certification operations.", Project, Hybrid, 900.0, 720.0),
    d!(Run, "Governed project launch and runtime surface.", Project, Hybrid, 760.0, 520.0),
    d!(Updates, "Project-aware patch and application update workflow.", Project, Shadow, 960.0, 720.0),
    d!(Recovery, "Repair, debug handoff and source recovery tools.", Project, Hybrid, 860.0, 620.0),
    d!(Diagnostics, "Health, self-test, debug bundle and evidence tools.", Project, Hybrid, 900.0, 700.0),
    d!(Artifacts, "Project outputs, packages, logs and Artifact Central.", Project, Shadow, 900.0, 700.0),
    d!(ProjectTools, "Searchable governed tooling/command catalog plus Internal PCC entry points.", Project, Hybrid, 940.0, 720.0),
    d!(ProjectCli, "Visual registered-command form and safe project CLI alias runner.", Project, Hybrid, 900.0, 640.0),
    d!(ProjectIntelligence, "Bounded project census, toolchains and inferred operations.", Project, Native, 1020.0, 760.0),
    d!(NativeMigration, "Rust parity, certification and takeover evidence.", Project, Native, 980.0, 720.0),
    d!(AssetDependencies, "Missing-asset diagnosis and Vault hydration workflow.", Project, Hybrid, 900.0, 640.0),
    d!(ForgeConsole, "Persistent Forge operation transcript and command composer.", Project, Native, 980.0, 720.0),
    d!(OperationQueue, "Foreground single-flight operation queue and cancellation.", Project, Native, 900.0, 640.0),
    d!(ProjectHealth, "Selected-project health, contract and migration summary.", Project, Native, 440.0, 600.0),
    d!(PatchIntake, "Single governed patch, update and artifact intake surface.", Project, Shadow, 520.0, 620.0),
    d!(ProjectContext, "Bound root, contract, PCC and toolchain context.", Project, Native, 480.0, 560.0),
    d!(RecentActivity, "Recent operation result and queue activity.", Project, Native, 520.0, 540.0),
    d!(Vault, "Project library, catalog, assets and storage authority.", Workspace, Shadow, 1100.0, 760.0),
    d!(Workspace, "Project files and authoring workspace.", Workspace, Shadow, 1180.0, 800.0),
    d!(Settings, "Forge configuration, paths and integrations.", System, Hybrid, 860.0, 700.0),
    d!(InterfaceManager, "Panel library, presets, custom interfaces and layout locking.", Global, Native, 900.0, 700.0),
    d!(Status, "Compact project, operation, interface and version status surface.", Global, Native, 900.0, 260.0),
];

pub fn descriptor(panel: ToolPanel) -> &'static PanelDescriptor {
    PANELS.iter().find(|row| row.panel == panel).expect("every ToolPanel must have a descriptor")
}

pub fn find(query: &str) -> Vec<&'static PanelDescriptor> {
    let q = query.trim().to_ascii_lowercase();
    PANELS.iter().filter(|row| {
        q.is_empty()
            || row.id.contains(&q)
            || row.title.to_ascii_lowercase().contains(&q)
            || row.category.to_ascii_lowercase().contains(&q)
            || row.summary.to_ascii_lowercase().contains(&q)
    }).collect()
}


/// Stable semantic icon identity exported through ForgeGUI.  Forge may keep its
/// legacy display glyphs while saved definitions and future hosts use these keys.
pub const fn forge_gui_icon(panel: ToolPanel) -> IconId {
    match panel {
        ToolPanel::ForgeNavigator | ToolPanel::ProjectNavigator => IconId::Project,
        ToolPanel::QuickActions | ToolPanel::BuildTest => IconId::Build,
        ToolPanel::Overview | ToolPanel::ProjectHealth | ToolPanel::Status => IconId::Info,
        ToolPanel::Source => IconId::GitBranch,
        ToolPanel::Run => IconId::Play,
        ToolPanel::Updates | ToolPanel::PatchIntake => IconId::Patch,
        ToolPanel::Recovery => IconId::Restart,
        ToolPanel::Diagnostics => IconId::Problems,
        ToolPanel::Artifacts | ToolPanel::AssetDependencies | ToolPanel::Vault => IconId::Asset,
        ToolPanel::ProjectTools | ToolPanel::ProjectCli => IconId::Terminal,
        ToolPanel::ProjectIntelligence => IconId::Search,
        ToolPanel::NativeMigration => IconId::Build,
        ToolPanel::ForgeConsole => IconId::Console,
        ToolPanel::OperationQueue | ToolPanel::RecentActivity => IconId::History,
        ToolPanel::ProjectContext => IconId::Inspector,
        ToolPanel::Workspace => IconId::FolderOpen,
        ToolPanel::Settings => IconId::Settings,
        ToolPanel::InterfaceManager => IconId::Layers,
    }
}

fn forge_gui_role(panel: ToolPanel) -> PanelRole {
    match panel {
        ToolPanel::ForgeNavigator => PanelRole::Navigation,
        ToolPanel::ProjectNavigator => PanelRole::Explorer,
        ToolPanel::QuickActions | ToolPanel::PatchIntake | ToolPanel::Recovery => PanelRole::Utility,
        ToolPanel::Overview | ToolPanel::ProjectIntelligence => PanelRole::Data,
        ToolPanel::Source | ToolPanel::Workspace => PanelRole::Document,
        ToolPanel::BuildTest | ToolPanel::Run | ToolPanel::Updates | ToolPanel::OperationQueue => PanelRole::Operations,
        ToolPanel::Diagnostics => PanelRole::Diagnostics,
        ToolPanel::Artifacts | ToolPanel::AssetDependencies | ToolPanel::Vault => PanelRole::Assets,
        ToolPanel::ProjectTools | ToolPanel::ProjectCli => PanelRole::Tool,
        ToolPanel::NativeMigration | ToolPanel::ProjectHealth | ToolPanel::Status => PanelRole::Monitor,
        ToolPanel::ForgeConsole => PanelRole::Console,
        ToolPanel::ProjectContext => PanelRole::Inspector,
        ToolPanel::RecentActivity => PanelRole::History,
        ToolPanel::Settings | ToolPanel::InterfaceManager => PanelRole::Settings,
    }
}

fn forge_gui_dock(panel: ToolPanel) -> PreferredDock {
    match panel.shell_anchor() {
        Some(ShellAnchor::LeftNavigation) => PreferredDock::Left,
        Some(ShellAnchor::RightContext) => PreferredDock::Right,
        Some(ShellAnchor::BottomConsole) | Some(ShellAnchor::Status) => PreferredDock::Bottom,
        Some(ShellAnchor::TopCommand) | None => PreferredDock::Center,
    }
}

fn forge_gui_scope(scope: PanelScope) -> ForgeGuiPanelScope {
    match scope {
        PanelScope::Global | PanelScope::System => ForgeGuiPanelScope::Global,
        PanelScope::Project | PanelScope::Workspace => ForgeGuiPanelScope::Project,
    }
}

/// Adapter from the Forge application registry into the reusable ForgeGUI
/// renderer-neutral panel contract.  The Forge descriptor remains the migration
/// authority for maturity and application-specific metadata; ForgeGUI owns the
/// reusable panel identity/docking/hosting vocabulary.
pub fn forge_gui_definition(panel: ToolPanel) -> PanelDefinition {
    let descriptor = descriptor(panel);
    let mut definition = PanelDefinition::new(
        format!("forge.panel.{}", descriptor.id),
        descriptor.title,
        forge_gui_role(panel),
        forge_gui_dock(panel),
    );
    definition.category = descriptor.category.to_string();
    definition.summary = descriptor.summary.to_string();
    definition.icon = Some(forge_gui_icon(panel).key().to_string());
    definition.scope = forge_gui_scope(descriptor.scope);
    definition.host_mode = if panel.shell_anchor().is_some() {
        HostMode::Structural
    } else if descriptor.standalone {
        HostMode::DockedOrWindow
    } else {
        HostMode::Docked
    };
    definition.instance_policy = if descriptor.singleton {
        InstancePolicy::Singleton
    } else {
        InstancePolicy::Multiple { max_instances: None }
    };
    definition.minimum_size = descriptor.minimum_size;
    definition.preferred_size = descriptor.preferred_size;
    definition
}

pub fn forge_gui_catalog() -> PanelCatalog {
    let mut catalog = PanelCatalog::default();
    for panel in ToolPanel::ALL {
        catalog
            .register(forge_gui_definition(panel))
            .expect("Forge panel definitions must satisfy ForgeGUI contract");
    }
    catalog
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;

    #[test]
    fn registry_covers_every_panel_with_unique_ids() {
        assert_eq!(PANELS.len(), ToolPanel::ALL.len());
        let ids: HashSet<_> = PANELS.iter().map(|row| row.id).collect();
        assert_eq!(ids.len(), PANELS.len());
        for panel in ToolPanel::ALL { assert_eq!(descriptor(panel).id, panel.slug()); }
    }

    #[test]
    fn every_panel_is_standalone_capable() {
        assert!(PANELS.iter().all(|row| row.standalone));
    }

    #[test]
    fn forgegui_catalog_covers_every_forge_panel() {
        let catalog = forge_gui_catalog();
        assert_eq!(catalog.len(), ToolPanel::ALL.len());
        for panel in ToolPanel::ALL {
            let definition = forge_gui_definition(panel);
            assert!(definition.id.as_str().starts_with("forge.panel."));
            assert_eq!(definition.title, panel.title());
            definition.validate().unwrap();
        }
    }

    #[test]
    fn forgegui_definitions_use_semantic_icon_keys_not_display_glyphs() {
        for panel in ToolPanel::ALL {
            let definition = forge_gui_definition(panel);
            let expected = forge_gui_icon(panel);
            assert_eq!(definition.icon.as_deref(), Some(expected.key()));
            assert!(!expected.fallback().is_empty());
        }
    }

    #[test]
    fn shell_anchors_are_structural_in_forgegui_contract() {
        for panel in ToolPanel::ALL {
            let definition = forge_gui_definition(panel);
            if panel.shell_anchor().is_some() {
                assert_eq!(definition.host_mode, HostMode::Structural);
            }
        }
    }
}
