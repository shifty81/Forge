from pathlib import Path
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
REV = "1829f2a7690ecd6eac401c830ec0adeb1c56af47"


class ForgeGuiIntegrationTests(unittest.TestCase):
    def test_cargo_pins_forgegui_source_exactly(self):
        cargo = (ROOT / "native" / "forge-rs" / "Cargo.toml").read_text(encoding="utf-8")
        self.assertIn('forge_gui_core = { git = "https://github.com/shifty81/ForgeGui.git"', cargo)
        self.assertIn(f'rev = "{REV}"', cargo)
        self.assertNotIn('branch = "main"', cargo)

    def test_theme_uses_forgegui_tokens(self):
        theme = (ROOT / "native" / "forge-rs" / "src" / "gui" / "theme.rs").read_text(encoding="utf-8")
        self.assertIn("use forge_gui_core::{Rgba, ThemeTokens, FORGE_GUI_API_VERSION};", theme)
        self.assertIn("pub fn tokens() -> ThemeTokens", theme)
        self.assertIn("scrollbar_width", theme)
        self.assertIn(REV, theme)

    def test_registry_exports_all_panels_to_forgegui_contract(self):
        registry = (ROOT / "native" / "forge-rs" / "src" / "gui" / "registry.rs").read_text(encoding="utf-8")
        self.assertIn("pub fn forge_gui_definition(panel: ToolPanel) -> PanelDefinition", registry)
        self.assertIn("pub fn forge_gui_catalog() -> PanelCatalog", registry)
        self.assertIn('format!("forge.panel.{}", descriptor.id)', registry)
        self.assertIn("HostMode::Structural", registry)
        self.assertIn(REV, registry)

    def test_forgegui_does_not_take_project_operation_authority(self):
        contract = (ROOT / "native" / "forge-rs" / "src" / "gui" / "contract.rs").read_text(encoding="utf-8")
        self.assertIn("FORGE_GUI_DOES_NOT_OWN_PROJECT_OPERATIONS: bool = true", contract)
        self.assertIn("FORGE_GUI_THEME_TOKENS_ARE_AUTHORITATIVE: bool = true", contract)
        self.assertIn("FORGE_GUI_PANEL_DEFINITIONS_MIRROR_REGISTRY: bool = true", contract)


if __name__ == "__main__":
    unittest.main()
