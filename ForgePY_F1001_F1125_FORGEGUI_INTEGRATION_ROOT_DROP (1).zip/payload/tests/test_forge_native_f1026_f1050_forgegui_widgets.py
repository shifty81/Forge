from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
CARGO = ROOT / "native" / "forge-rs" / "Cargo.toml"
REGISTRY = ROOT / "native" / "forge-rs" / "src" / "gui" / "registry.rs"
THEME = ROOT / "native" / "forge-rs" / "src" / "gui" / "theme.rs"
CONTRACT = ROOT / "native" / "forge-rs" / "src" / "gui" / "contract.rs"
REV = "1829f2a7690ecd6eac401c830ec0adeb1c56af47"

class ForgeGuiWidgetIntegration(unittest.TestCase):
    def test_icons_and_widgets_are_exact_source_pinned(self):
        text = CARGO.read_text(encoding="utf-8")
        self.assertIn('forge_gui_icons = { git = "https://github.com/shifty81/ForgeGui.git", rev = "' + REV, text)
        self.assertIn('forge_gui_widgets = { git = "https://github.com/shifty81/ForgeGui.git", rev = "' + REV, text)
        self.assertNotIn('branch = "main"', text)

    def test_panel_contract_uses_semantic_icon_keys(self):
        text = REGISTRY.read_text(encoding="utf-8")
        self.assertIn("pub const fn forge_gui_icon", text)
        self.assertIn("forge_gui_icon(panel).key().to_string()", text)
        self.assertIn("IconId::Console", text)
        self.assertIn("IconId::Patch", text)
        self.assertIn("IconId::GitBranch", text)

    def test_host_installs_shared_icon_font_and_widget_adapter(self):
        text = THEME.read_text(encoding="utf-8")
        self.assertIn("forge_gui_widgets::add_default_icon_font", text)
        self.assertIn("forge_gui_widgets::icon_button", text)
        self.assertIn("forge_gui_widgets::labeled_icon_button", text)
        self.assertIn("FORGE_GUI_WIDGETS_BOUND", text)

    def test_operation_authority_does_not_move_to_gui_library(self):
        text = CONTRACT.read_text(encoding="utf-8")
        self.assertIn("FORGE_GUI_DOES_NOT_OWN_PROJECT_OPERATIONS: bool = true", text)
        self.assertIn("FORGE_GUI_WIDGET_ADAPTER_BOUND: bool = true", text)
        self.assertIn("FORGE_GUI_ICON_FONT_IS_HOST_INSTALLED: bool = true", text)

if __name__ == "__main__":
    unittest.main()
