from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
CARGO = ROOT / "native/forge-rs/Cargo.toml"
CONSOLE = ROOT / "native/forge-rs/src/gui/console.rs"
SYNC = ROOT / "tools/rust/ForgeGuiSourceSync.py"
CONTRACT = ROOT / "native/forge-rs/src/gui/contract.rs"
REV = "1829f2a7690ecd6eac401c830ec0adeb1c56af47"

class ForgeGuiConsoleWave(unittest.TestCase):
    def test_console_crate_is_exact_source_pinned(self):
        text = CARGO.read_text(encoding="utf-8")
        self.assertIn('forge_gui_console = { git = "https://github.com/shifty81/ForgeGui.git", rev = "' + REV, text)

    def test_console_uses_shared_level_vocabulary_without_losing_filters(self):
        text = CONSOLE.read_text(encoding="utf-8")
        self.assertIn("use forge_gui_console::ConsoleLevel", text)
        self.assertIn("ConsoleLevel::Success", text)
        self.assertIn("ConsoleChannel::Patch", text)
        self.assertIn("ConsoleChannel::Git", text)
        self.assertIn("shared.execute_console_command()", text)

    def test_source_sync_status_is_offline_and_exact_revision(self):
        with tempfile.TemporaryDirectory() as td:
            result = subprocess.run([sys.executable, str(SYNC), "status", "--root", td], capture_output=True, text=True, check=False)
            self.assertEqual(result.returncode, 0, result.stderr)
            row = json.loads(result.stdout)
            self.assertEqual(row["revision"], REV)
            self.assertTrue(row["checkout"].endswith(str(Path(".forge") / "deps" / "ForgeGui")))
            self.assertFalse(row["revisionReady"])

    def test_contract_preserves_forge_operation_authority(self):
        text = CONTRACT.read_text(encoding="utf-8")
        self.assertIn("FORGE_GUI_CONSOLE_LEVELS_BOUND: bool = true", text)
        self.assertIn("FORGE_GUI_SOURCE_SYNC_IS_EXACT_REVISION: bool = true", text)
        self.assertIn("FORGE_GUI_DOES_NOT_OWN_PROJECT_OPERATIONS: bool = true", text)

if __name__ == "__main__":
    unittest.main()
