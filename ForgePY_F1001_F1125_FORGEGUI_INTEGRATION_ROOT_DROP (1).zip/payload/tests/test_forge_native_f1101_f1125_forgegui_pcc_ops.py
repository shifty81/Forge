from __future__ import annotations

import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ForgeGuiPccOperationTests(unittest.TestCase):
    def test_project_contract_exposes_forgegui_operations(self) -> None:
        data = json.loads((ROOT / "project.control.json").read_text(encoding="utf-8"))
        rows = {row["key"]: row for row in data["commands"]}
        expected = {
            "audit.forgegui",
            "audit.forgegui-source",
            "audit.forgegui-source-verify",
            "tooling.forgegui-source-sync",
        }
        self.assertTrue(expected.issubset(rows))
        self.assertEqual(rows["audit.forgegui"]["risk"], "read")
        self.assertEqual(rows["audit.forgegui-source-verify"]["risk"], "read")
        self.assertEqual(rows["tooling.forgegui-source-sync"]["risk"], "write")
        self.assertTrue(rows["tooling.forgegui-source-sync"]["mutates"])

    def test_native_cargo_version_and_pins_move_cumulatively_forward(self) -> None:
        text = (ROOT / "native/forge-rs/Cargo.toml").read_text(encoding="utf-8")
        self.assertIn('version = "0.7.5"', text)
        self.assertGreaterEqual(text.count('rev = "1829f2a7690ecd6eac401c830ec0adeb1c56af47"'), 4)


if __name__ == "__main__":
    unittest.main()
