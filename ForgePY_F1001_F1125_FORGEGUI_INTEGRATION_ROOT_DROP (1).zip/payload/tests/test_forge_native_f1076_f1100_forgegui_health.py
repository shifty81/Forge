from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REV = "1829f2a7690ecd6eac401c830ec0adeb1c56af47"


class ForgeGuiHealthWaveTests(unittest.TestCase):
    def test_source_sync_is_fail_closed_and_exact(self) -> None:
        text = (ROOT / "tools/rust/ForgeGuiSourceSync.py").read_text(encoding="utf-8")
        self.assertIn(REV, text)
        self.assertIn('choices=("status", "sync", "verify")', text)
        self.assertIn("Refusing to modify dirty ForgeGUI donor checkout", text)
        self.assertIn("origin mismatch", text)
        self.assertIn("forgegui-source.json", text)

    def test_doctor_audits_all_shared_gui_seams(self) -> None:
        text = (ROOT / "tools/rust/ForgeGuiDoctor.py").read_text(encoding="utf-8")
        for dep in ("forge_gui_core", "forge_gui_icons", "forge_gui_widgets", "forge_gui_console"):
            self.assertIn(dep, text)
        for source in ("contract.rs", "registry.rs", "theme.rs", "console.rs"):
            self.assertIn(source, text)
        self.assertIn("forgegui-health.json", text)

    def test_doctor_passes_or_warns_without_optional_hydrated_source(self) -> None:
        result = subprocess.run(
            [sys.executable, str(ROOT / "tools/rust/ForgeGuiDoctor.py"), "--root", str(ROOT), "--json"],
            check=False,
            capture_output=True,
            text=True,
            timeout=30,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        payload = json.loads(result.stdout)
        self.assertIn(payload["state"], {"PASS", "WARN"})
        self.assertEqual(payload["failureCount"], 0)


if __name__ == "__main__":
    unittest.main()
